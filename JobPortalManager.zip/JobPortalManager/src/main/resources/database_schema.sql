-- Job Portal MySQL Database Schema with predefined users
-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS jobportal;
USE jobportal;

-- Drop tables if they exist to ensure clean setup
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS jobs;
DROP TABLE IF EXISTS job_seekers;
DROP TABLE IF EXISTS job_providers;
DROP TABLE IF EXISTS administrators;
DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    user_type INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create job_seekers table
CREATE TABLE job_seekers (
    user_id INT PRIMARY KEY,
    resume TEXT,
    skills TEXT,
    education TEXT,
    experience TEXT,
    preferences TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create job_providers table
CREATE TABLE job_providers (
    user_id INT PRIMARY KEY,
    company_name VARCHAR(100) NOT NULL,
    company_description TEXT,
    industry VARCHAR(100),
    website VARCHAR(255),
    location VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create administrators table
CREATE TABLE administrators (
    user_id INT PRIMARY KEY,
    role VARCHAR(50),
    department VARCHAR(100),
    access_level INT DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create jobs table
CREATE TABLE jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    requirements TEXT,
    responsibilities TEXT,
    location VARCHAR(100),
    type VARCHAR(50),
    category VARCHAR(100),
    salary DOUBLE,
    deadline_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (provider_id) REFERENCES job_providers(user_id) ON DELETE CASCADE
);

-- Create applications table
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    seeker_id INT NOT NULL,
    cover_letter TEXT,
    status VARCHAR(50) DEFAULT 'Pending',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (seeker_id) REFERENCES job_seekers(user_id) ON DELETE CASCADE
);

-- Insert predefined users
-- Job Seekers
INSERT INTO users (username, password, email, full_name, phone, user_type, created_at, is_active) VALUES
('dbangar', 'password123', 'devesh.bangar@example.com', 'Devesh Bangar', '9876543210', 1, NOW(), TRUE),
('kpatil', 'password123', 'kshitij.patil@example.com', 'Kshitij Patil', '9876543211', 1, NOW(), TRUE),
('akhare', 'password123', 'abhishek.khare@example.com', 'Abhishek Khare', '9876543212', 1, NOW(), TRUE),
('pgupta', 'password123', 'priya.gupta@example.com', 'Priya Gupta', '9876543213', 1, NOW(), TRUE);

-- Insert job seeker profile details
INSERT INTO job_seekers (user_id, resume, skills, education, experience, preferences) VALUES
(1, 'Experienced software developer with expertise in Java and web technologies.', 'Java, Spring, MySQL, Angular, React', 'B.Tech in Computer Science, IIT Mumbai', '3 years as Software Developer at TCS', 'Looking for opportunities in Mumbai or Pune'),
(2, 'Mechanical engineer with specialization in automobile design.', 'AutoCAD, SolidWorks, Machine Design', 'B.E. Mechanical Engineering, VJTI Mumbai', '2 years as Design Engineer at Mahindra', 'Interested in automobile industry jobs in Pune'),
(3, 'Experienced UI/UX designer with a portfolio of successful projects.', 'Figma, Adobe XD, HTML, CSS, UI/UX Research', 'B.Des in Design, NID Ahmedabad', '4 years as UI Designer at Infosys', 'Remote work opportunities preferred'),
(4, 'Data analyst with strong mathematical background.', 'Python, R, SQL, Data Visualization, Statistical Analysis', 'M.Sc Statistics, University of Pune', '2 years as Data Analyst at Wipro', 'Seeking data science roles in Mumbai');

-- Job Providers
INSERT INTO users (username, password, email, full_name, phone, user_type, created_at, is_active) VALUES
('tcs_hr', 'company123', 'hr@tcs.com', 'TCS HR Manager', '9876543220', 2, NOW(), TRUE),
('infosys_hr', 'company123', 'hr@infosys.com', 'Infosys HR Manager', '9876543221', 2, NOW(), TRUE),
('wipro_hr', 'company123', 'hr@wipro.com', 'Wipro HR Manager', '9876543222', 2, NOW(), TRUE);

-- Insert job provider profile details
INSERT INTO job_providers (user_id, company_name, company_description, industry, website, location) VALUES
(5, 'Tata Consultancy Services', 'Tata Consultancy Services is an Indian multinational information technology services and consulting company.', 'Information Technology', 'https://www.tcs.com', 'Mumbai'),
(6, 'Infosys', 'Infosys Limited is an Indian multinational information technology company that provides business consulting, information technology and outsourcing services.', 'Information Technology', 'https://www.infosys.com', 'Pune'),
(7, 'Wipro', 'Wipro Limited is an Indian multinational corporation that provides information technology, consulting and business process services.', 'Information Technology', 'https://www.wipro.com', 'Thane');

-- Administrator
INSERT INTO users (username, password, email, full_name, phone, user_type, created_at, is_active) VALUES
('admin', 'admin123', 'admin@jobportal.com', 'System Administrator', '9876543230', 3, NOW(), TRUE);

-- Insert administrator profile details
INSERT INTO administrators (user_id, role, department, access_level) VALUES
(8, 'System Administrator', 'IT Department', 3);

-- Insert sample jobs
INSERT INTO jobs (provider_id, title, description, requirements, responsibilities, location, type, category, salary, deadline_date, created_at, updated_at, is_active) VALUES
(5, 'Java Developer', 'We are looking for a Java developer to join our team in Mumbai.', 'Bachelor''s degree in Computer Science or related field. 2+ years of experience in Java development.', 'Develop and maintain Java applications. Write clean, maintainable code.', 'Mumbai', 'Full-time', 'Information Technology', 1200000, DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY), NOW(), NOW(), TRUE),
(5, 'Frontend Developer', 'TCS is hiring frontend developers with expertise in React.', 'Experience with React, HTML, CSS, and JavaScript. Understanding of responsive design.', 'Develop user interfaces using React. Collaborate with backend developers.', 'Mumbai', 'Full-time', 'Information Technology', 1000000, DATE_ADD(CURRENT_DATE, INTERVAL 15 DAY), NOW(), NOW(), TRUE),
(6, 'Database Administrator', 'Join Infosys as a Database Administrator in our Pune office.', 'Strong knowledge of MySQL, PostgreSQL. 3+ years of experience in database administration.', 'Manage and optimize database systems. Ensure data security and availability.', 'Pune', 'Full-time', 'Information Technology', 1500000, DATE_ADD(CURRENT_DATE, INTERVAL 45 DAY), NOW(), NOW(), TRUE),
(6, 'UI/UX Designer', 'Infosys is seeking a talented UI/UX Designer to create beautiful interfaces.', 'Experience with Figma or Adobe XD. Portfolio demonstrating UI/UX projects.', 'Design user interfaces for web and mobile applications. Conduct user research.', 'Pune', 'Full-time', 'Design', 900000, DATE_ADD(CURRENT_DATE, INTERVAL 20 DAY), NOW(), NOW(), TRUE),
(7, 'Data Scientist', 'Join Wipro as a Data Scientist to work on exciting data projects.', 'Master''s degree in Statistics, Computer Science, or related field. Knowledge of Python and R.', 'Analyze and interpret complex data. Develop machine learning models.', 'Thane', 'Full-time', 'Data Science', 1800000, DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY), NOW(), NOW(), TRUE),
(7, 'Network Engineer', 'Wipro is looking for a Network Engineer to join our infrastructure team.', 'CCNA certification. Experience with network troubleshooting.', 'Maintain and troubleshoot network systems. Configure network equipment.', 'Mumbai', 'Full-time', 'Networking', 950000, DATE_ADD(CURRENT_DATE, INTERVAL 25 DAY), NOW(), NOW(), TRUE);

-- Insert sample applications
INSERT INTO applications (job_id, seeker_id, cover_letter, status, applied_at, updated_at, notes) VALUES
(1, 1, 'I am very interested in this Java Developer position at TCS. My experience with Java and Spring makes me a great fit for this role.', 'Reviewing', DATE_SUB(NOW(), INTERVAL 5 DAY), NOW(), 'Candidate has good Java skills.'),
(3, 1, 'I would like to apply for the Database Administrator position. While my primary experience is in Java development, I have also worked extensively with databases.', 'Pending', DATE_SUB(NOW(), INTERVAL 2 DAY), NOW(), NULL),
(2, 3, 'As a UI/UX designer, I am also proficient in frontend development and would be a great fit for this position.', 'Shortlisted', DATE_SUB(NOW(), INTERVAL 7 DAY), NOW(), 'Good portfolio, schedule for interview.'),
(5, 4, 'With my background in statistics and data analysis, I believe I would be a valuable addition to your data science team.', 'Interview', DATE_SUB(NOW(), INTERVAL 10 DAY), NOW(), 'Interview scheduled for next week.');