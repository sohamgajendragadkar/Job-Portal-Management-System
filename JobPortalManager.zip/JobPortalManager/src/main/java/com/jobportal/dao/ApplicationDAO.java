package com.jobportal.dao;

import com.jobportal.model.Application;
import com.jobportal.model.Job;
import com.jobportal.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Application-related database operations.
 * Handles CRUD operations for job applications.
 */
public class ApplicationDAO {
    
    /**
     * Creates a new job application in the database
     * 
     * @param application The Application to create
     * @return The created Application with ID assigned, or null if creation failed
     * @throws SQLException If a database error occurs
     */
    public Application createApplication(Application application) throws SQLException {
        String sql = "INSERT INTO applications (job_id, seeker_id, cover_letter, status, applied_at, updated_at, notes) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, application.getJobId());
            stmt.setInt(2, application.getSeekerId());
            stmt.setString(3, application.getCoverLetter());
            stmt.setString(4, application.getStatus());
            stmt.setTimestamp(5, Timestamp.valueOf(application.getAppliedAt()));
            stmt.setTimestamp(6, Timestamp.valueOf(application.getUpdatedAt()));
            stmt.setString(7, application.getNotes());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        application.setId(generatedKeys.getInt(1));
                        return application;
                    }
                }
            }
            
            return null;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Retrieves an application by its ID
     * 
     * @param applicationId The ID of the application to retrieve
     * @return The Application object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public Application getApplicationById(int applicationId) throws SQLException {
        String sql = "SELECT * FROM applications WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, applicationId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractApplicationFromResultSet(rs);
                }
                return null;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Updates an application in the database
     * 
     * @param application The Application to update
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateApplication(Application application) throws SQLException {
        String sql = "UPDATE applications SET status = ?, updated_at = ?, notes = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, application.getStatus());
            stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setString(3, application.getNotes());
            stmt.setInt(4, application.getId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Checks if a job seeker has already applied to a job
     * 
     * @param jobId The job ID
     * @param seekerId The job seeker ID
     * @return true if the seeker has already applied, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean hasApplied(int jobId, int seekerId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM applications WHERE job_id = ? AND seeker_id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, jobId);
            stmt.setInt(2, seekerId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
                return false;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets all applications for a specific job
     * 
     * @param jobId The ID of the job
     * @return List of applications for the job
     * @throws SQLException If a database error occurs
     */
    public List<Application> getApplicationsByJob(int jobId) throws SQLException {
        List<Application> applications = new ArrayList<>();
        String sql = "SELECT * FROM applications WHERE job_id = ? ORDER BY applied_at DESC";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, jobId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    applications.add(extractApplicationFromResultSet(rs));
                }
                return applications;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets all applications submitted by a specific job seeker
     * 
     * @param seekerId The ID of the job seeker
     * @return List of applications submitted by the job seeker
     * @throws SQLException If a database error occurs
     */
    public List<Application> getApplicationsBySeeker(int seekerId) throws SQLException {
        List<Application> applications = new ArrayList<>();
        String sql = "SELECT * FROM applications WHERE seeker_id = ? ORDER BY applied_at DESC";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, seekerId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    applications.add(extractApplicationFromResultSet(rs));
                }
                return applications;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets job seeker applications with corresponding job details
     * 
     * @param seekerId The ID of the job seeker
     * @return List of applications with job details
     * @throws SQLException If a database error occurs
     */
    public List<Object[]> getApplicationsWithJobDetails(int seekerId) throws SQLException {
        List<Object[]> results = new ArrayList<>();
        
        String sql = "SELECT a.*, j.title, j.location, j.type, j.provider_id, jp.company_name " +
                    "FROM applications a " +
                    "JOIN jobs j ON a.job_id = j.id " +
                    "JOIN job_providers jp ON j.provider_id = jp.user_id " +
                    "WHERE a.seeker_id = ? " +
                    "ORDER BY a.applied_at DESC";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, seekerId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Application application = extractApplicationFromResultSet(rs);
                    
                    // Extract job details
                    Job job = new Job();
                    job.setId(rs.getInt("job_id"));
                    job.setTitle(rs.getString("title"));
                    job.setLocation(rs.getString("location"));
                    job.setType(rs.getString("type"));
                    job.setProviderId(rs.getInt("provider_id"));
                    
                    String companyName = rs.getString("company_name");
                    
                    // Create result array
                    Object[] result = {application, job, companyName};
                    results.add(result);
                }
                return results;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Withdraws an application from consideration
     * 
     * @param applicationId The ID of the application to withdraw
     * @param seekerId The ID of the job seeker (for verification)
     * @return true if withdrawal was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean withdrawApplication(int applicationId, int seekerId) throws SQLException {
        String sql = "UPDATE applications SET status = ?, updated_at = ? " +
                    "WHERE id = ? AND seeker_id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, Application.STATUS_WITHDRAWN);
            stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(3, applicationId);
            stmt.setInt(4, seekerId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets application statistics for a job provider
     * 
     * @param providerId The ID of the job provider
     * @return Map containing statistics information
     * @throws SQLException If a database error occurs
     */
    public int[] getApplicationStatistics(int providerId) throws SQLException {
        String sql = "SELECT " +
                    "(SELECT COUNT(*) FROM applications a JOIN jobs j ON a.job_id = j.id WHERE j.provider_id = ?) AS total, " +
                    "(SELECT COUNT(*) FROM applications a JOIN jobs j ON a.job_id = j.id WHERE j.provider_id = ? AND a.status = ?) AS pending, " +
                    "(SELECT COUNT(*) FROM applications a JOIN jobs j ON a.job_id = j.id WHERE j.provider_id = ? AND a.status = ?) AS reviewing, " +
                    "(SELECT COUNT(*) FROM applications a JOIN jobs j ON a.job_id = j.id WHERE j.provider_id = ? AND a.status = ?) AS shortlisted, " +
                    "(SELECT COUNT(*) FROM applications a JOIN jobs j ON a.job_id = j.id WHERE j.provider_id = ? AND a.status = ?) AS hired";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, providerId);
            stmt.setInt(2, providerId);
            stmt.setString(3, Application.STATUS_PENDING);
            stmt.setInt(4, providerId);
            stmt.setString(5, Application.STATUS_REVIEWING);
            stmt.setInt(6, providerId);
            stmt.setString(7, Application.STATUS_SHORTLISTED);
            stmt.setInt(8, providerId);
            stmt.setString(9, Application.STATUS_HIRED);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int[] stats = new int[5];
                    stats[0] = rs.getInt("total");
                    stats[1] = rs.getInt("pending");
                    stats[2] = rs.getInt("reviewing");
                    stats[3] = rs.getInt("shortlisted");
                    stats[4] = rs.getInt("hired");
                    return stats;
                }
                return new int[5]; // Return empty stats if no data found
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Extracts an Application object from a ResultSet
     * 
     * @param rs The ResultSet containing application data
     * @return An Application object
     * @throws SQLException If a database error occurs
     */
    private Application extractApplicationFromResultSet(ResultSet rs) throws SQLException {
        Application application = new Application();
        
        application.setId(rs.getInt("id"));
        application.setJobId(rs.getInt("job_id"));
        application.setSeekerId(rs.getInt("seeker_id"));
        application.setCoverLetter(rs.getString("cover_letter"));
        application.setStatus(rs.getString("status"));
        
        Timestamp appliedAt = rs.getTimestamp("applied_at");
        if (appliedAt != null) {
            application.setAppliedAt(appliedAt.toLocalDateTime());
        }
        
        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) {
            application.setUpdatedAt(updatedAt.toLocalDateTime());
        }
        
        application.setNotes(rs.getString("notes"));
        
        return application;
    }
}
