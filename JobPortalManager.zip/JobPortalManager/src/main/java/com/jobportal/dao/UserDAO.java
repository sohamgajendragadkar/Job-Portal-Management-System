package com.jobportal.dao;

import com.jobportal.model.*;
import com.jobportal.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for User-related database operations.
 * Handles CRUD operations for all user types.
 */
public class UserDAO {
    
    /**
     * Authenticates a user by username and password
     * 
     * @param username The username to authenticate
     * @param password The password to verify
     * @return A User object if authentication succeeds, null otherwise
     * @throws SQLException If a database error occurs
     */
    public User authenticateUser(String username, String password) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            stmt.setString(2, password); // In production, use password hashing
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int userType = rs.getInt("user_type");
                    int userId = rs.getInt("id");
                    
                    // Update last login time
                    updateLastLogin(userId);
                    
                    // Return the appropriate user type
                    switch (userType) {
                        case User.JOB_SEEKER:
                            return getJobSeekerById(userId);
                        case User.JOB_PROVIDER:
                            return getJobProviderById(userId);
                        case User.ADMINISTRATOR:
                            return getAdminById(userId);
                        default:
                            return null;
                    }
                }
                return null;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Update the last login timestamp for a user
     * 
     * @param userId The ID of the user to update
     * @throws SQLException If a database error occurs
     */
    private void updateLastLogin(int userId) throws SQLException {
        String sql = "UPDATE users SET last_login = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(2, userId);
            stmt.executeUpdate();
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Retrieves a JobSeeker by ID
     * 
     * @param id The ID of the JobSeeker to retrieve
     * @return The JobSeeker object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public JobSeeker getJobSeekerById(int id) throws SQLException {
        String sql = "SELECT u.*, js.resume, js.skills, js.education, js.experience, js.preferences " +
                     "FROM users u " +
                     "JOIN job_seekers js ON u.id = js.user_id " +
                     "WHERE u.id = ? AND u.user_type = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.setInt(2, User.JOB_SEEKER);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractJobSeekerFromResultSet(rs);
                }
                return null;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Retrieves a JobProvider by ID
     * 
     * @param id The ID of the JobProvider to retrieve
     * @return The JobProvider object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public JobProvider getJobProviderById(int id) throws SQLException {
        String sql = "SELECT u.*, jp.company_name, jp.company_description, jp.industry, jp.website, jp.location " +
                     "FROM users u " +
                     "JOIN job_providers jp ON u.id = jp.user_id " +
                     "WHERE u.id = ? AND u.user_type = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.setInt(2, User.JOB_PROVIDER);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractJobProviderFromResultSet(rs);
                }
                return null;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Retrieves an Administrator by ID
     * 
     * @param id The ID of the Administrator to retrieve
     * @return The Administrator object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public Administrator getAdminById(int id) throws SQLException {
        String sql = "SELECT u.*, a.role, a.department, a.access_level " +
                     "FROM users u " +
                     "JOIN administrators a ON u.id = a.user_id " +
                     "WHERE u.id = ? AND u.user_type = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.setInt(2, User.ADMINISTRATOR);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractAdminFromResultSet(rs);
                }
                return null;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Creates a new JobSeeker in the database
     * 
     * @param jobSeeker The JobSeeker to create
     * @return The created JobSeeker with ID assigned, or null if creation failed
     * @throws SQLException If a database error occurs
     */
    public JobSeeker createJobSeeker(JobSeeker jobSeeker) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet generatedKeys = null;
        
        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);
            
            // First, insert into users table
            String userSql = "INSERT INTO users (username, password, email, full_name, phone, " +
                              "user_type, created_at, is_active) " +
                              "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            stmt = conn.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, jobSeeker.getUsername());
            stmt.setString(2, jobSeeker.getPassword()); // In production, use password hashing
            stmt.setString(3, jobSeeker.getEmail());
            stmt.setString(4, jobSeeker.getFullName());
            stmt.setString(5, jobSeeker.getPhone());
            stmt.setInt(6, User.JOB_SEEKER);
            stmt.setTimestamp(7, Timestamp.valueOf(jobSeeker.getCreatedAt()));
            stmt.setBoolean(8, jobSeeker.isActive());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Creating user failed, no rows affected.");
            }
            
            generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int userId = generatedKeys.getInt(1);
                jobSeeker.setId(userId);
                
                // Now insert into job_seekers table
                String seekerSql = "INSERT INTO job_seekers (user_id, resume, skills, education, experience, preferences) " +
                                   "VALUES (?, ?, ?, ?, ?, ?)";
                
                stmt = conn.prepareStatement(seekerSql);
                stmt.setInt(1, userId);
                stmt.setString(2, jobSeeker.getResume());
                stmt.setString(3, jobSeeker.getSkills());
                stmt.setString(4, jobSeeker.getEducation());
                stmt.setString(5, jobSeeker.getExperience());
                stmt.setString(6, jobSeeker.getPreferences());
                
                rowsAffected = stmt.executeUpdate();
                if (rowsAffected == 0) {
                    throw new SQLException("Creating job seeker details failed, no rows affected.");
                }
                
                conn.commit();
                return jobSeeker;
            } else {
                throw new SQLException("Creating user failed, no ID obtained.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            // Rollback transaction if error occurs
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new SQLException("Rollback failed", ex);
                }
            }
            throw new SQLException("Error creating job seeker", e);
        } finally {
            // Close resources and reset auto-commit
            if (generatedKeys != null) try { generatedKeys.close(); } catch (SQLException e) { /* ignored */ }
            if (stmt != null) try { stmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { /* ignored */ }
            }
        }
    }
    
    /**
     * Creates a new JobProvider in the database
     * 
     * @param jobProvider The JobProvider to create
     * @return The created JobProvider with ID assigned, or null if creation failed
     * @throws SQLException If a database error occurs
     */
    public JobProvider createJobProvider(JobProvider jobProvider) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet generatedKeys = null;
        
        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);
            
            // First, insert into users table
            String userSql = "INSERT INTO users (username, password, email, full_name, phone, " +
                              "user_type, created_at, is_active) " +
                              "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            stmt = conn.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, jobProvider.getUsername());
            stmt.setString(2, jobProvider.getPassword()); // In production, use password hashing
            stmt.setString(3, jobProvider.getEmail());
            stmt.setString(4, jobProvider.getFullName());
            stmt.setString(5, jobProvider.getPhone());
            stmt.setInt(6, User.JOB_PROVIDER);
            stmt.setTimestamp(7, Timestamp.valueOf(jobProvider.getCreatedAt()));
            stmt.setBoolean(8, jobProvider.isActive());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Creating user failed, no rows affected.");
            }
            
            generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int userId = generatedKeys.getInt(1);
                jobProvider.setId(userId);
                
                // Now insert into job_providers table
                String providerSql = "INSERT INTO job_providers (user_id, company_name, company_description, " +
                                    "industry, website, location) " +
                                    "VALUES (?, ?, ?, ?, ?, ?)";
                
                stmt = conn.prepareStatement(providerSql);
                stmt.setInt(1, userId);
                stmt.setString(2, jobProvider.getCompanyName());
                stmt.setString(3, jobProvider.getCompanyDescription());
                stmt.setString(4, jobProvider.getIndustry());
                stmt.setString(5, jobProvider.getWebsite());
                stmt.setString(6, jobProvider.getLocation());
                
                rowsAffected = stmt.executeUpdate();
                if (rowsAffected == 0) {
                    throw new SQLException("Creating job provider details failed, no rows affected.");
                }
                
                conn.commit();
                return jobProvider;
            } else {
                throw new SQLException("Creating user failed, no ID obtained.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            // Rollback transaction if error occurs
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new SQLException("Rollback failed", ex);
                }
            }
            throw new SQLException("Error creating job provider", e);
        } finally {
            // Close resources and reset auto-commit
            if (generatedKeys != null) try { generatedKeys.close(); } catch (SQLException e) { /* ignored */ }
            if (stmt != null) try { stmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { /* ignored */ }
            }
        }
    }
    
    /**
     * Creates a new Administrator in the database
     * 
     * @param admin The Administrator to create
     * @return The created Administrator with ID assigned, or null if creation failed
     * @throws SQLException If a database error occurs
     */
    public Administrator createAdmin(Administrator admin) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet generatedKeys = null;
        
        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);
            
            // First, insert into users table
            String userSql = "INSERT INTO users (username, password, email, full_name, phone, " +
                              "user_type, created_at, is_active) " +
                              "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            stmt = conn.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, admin.getUsername());
            stmt.setString(2, admin.getPassword()); // In production, use password hashing
            stmt.setString(3, admin.getEmail());
            stmt.setString(4, admin.getFullName());
            stmt.setString(5, admin.getPhone());
            stmt.setInt(6, User.ADMINISTRATOR);
            stmt.setTimestamp(7, Timestamp.valueOf(admin.getCreatedAt()));
            stmt.setBoolean(8, admin.isActive());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Creating user failed, no rows affected.");
            }
            
            generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int userId = generatedKeys.getInt(1);
                admin.setId(userId);
                
                // Now insert into administrators table
                String adminSql = "INSERT INTO administrators (user_id, role, department, access_level) " +
                                  "VALUES (?, ?, ?, ?)";
                
                stmt = conn.prepareStatement(adminSql);
                stmt.setInt(1, userId);
                stmt.setString(2, admin.getRole());
                stmt.setString(3, admin.getDepartment());
                stmt.setInt(4, admin.getAccessLevel());
                
                rowsAffected = stmt.executeUpdate();
                if (rowsAffected == 0) {
                    throw new SQLException("Creating administrator details failed, no rows affected.");
                }
                
                conn.commit();
                return admin;
            } else {
                throw new SQLException("Creating user failed, no ID obtained.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            // Rollback transaction if error occurs
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new SQLException("Rollback failed", ex);
                }
            }
            throw new SQLException("Error creating administrator", e);
        } finally {
            // Close resources and reset auto-commit
            if (generatedKeys != null) try { generatedKeys.close(); } catch (SQLException e) { /* ignored */ }
            if (stmt != null) try { stmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { /* ignored */ }
            }
        }
    }
    
    /**
     * Updates a JobSeeker in the database
     * 
     * @param jobSeeker The JobSeeker to update
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateJobSeeker(JobSeeker jobSeeker) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);
            
            // Update users table
            String userSql = "UPDATE users SET email = ?, full_name = ?, phone = ?, is_active = ? " +
                             "WHERE id = ? AND user_type = ?";
            
            stmt = conn.prepareStatement(userSql);
            stmt.setString(1, jobSeeker.getEmail());
            stmt.setString(2, jobSeeker.getFullName());
            stmt.setString(3, jobSeeker.getPhone());
            stmt.setBoolean(4, jobSeeker.isActive());
            stmt.setInt(5, jobSeeker.getId());
            stmt.setInt(6, User.JOB_SEEKER);
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Updating user failed, no rows affected.");
            }
            
            // Update job_seekers table
            String seekerSql = "UPDATE job_seekers SET resume = ?, skills = ?, education = ?, " +
                               "experience = ?, preferences = ? WHERE user_id = ?";
            
            stmt = conn.prepareStatement(seekerSql);
            stmt.setString(1, jobSeeker.getResume());
            stmt.setString(2, jobSeeker.getSkills());
            stmt.setString(3, jobSeeker.getEducation());
            stmt.setString(4, jobSeeker.getExperience());
            stmt.setString(5, jobSeeker.getPreferences());
            stmt.setInt(6, jobSeeker.getId());
            
            rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Updating job seeker details failed, no rows affected.");
            }
            
            conn.commit();
            return true;
        } catch (SQLException | ClassNotFoundException e) {
            // Rollback transaction if error occurs
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new SQLException("Rollback failed", ex);
                }
            }
            throw new SQLException("Error updating job seeker", e);
        } finally {
            // Close resources and reset auto-commit
            if (stmt != null) try { stmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { /* ignored */ }
            }
        }
    }
    
    /**
     * Updates a JobProvider in the database
     * 
     * @param jobProvider The JobProvider to update
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateJobProvider(JobProvider jobProvider) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);
            
            // Update users table
            String userSql = "UPDATE users SET email = ?, full_name = ?, phone = ?, is_active = ? " +
                             "WHERE id = ? AND user_type = ?";
            
            stmt = conn.prepareStatement(userSql);
            stmt.setString(1, jobProvider.getEmail());
            stmt.setString(2, jobProvider.getFullName());
            stmt.setString(3, jobProvider.getPhone());
            stmt.setBoolean(4, jobProvider.isActive());
            stmt.setInt(5, jobProvider.getId());
            stmt.setInt(6, User.JOB_PROVIDER);
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Updating user failed, no rows affected.");
            }
            
            // Update job_providers table
            String providerSql = "UPDATE job_providers SET company_name = ?, company_description = ?, " +
                                "industry = ?, website = ?, location = ? WHERE user_id = ?";
            
            stmt = conn.prepareStatement(providerSql);
            stmt.setString(1, jobProvider.getCompanyName());
            stmt.setString(2, jobProvider.getCompanyDescription());
            stmt.setString(3, jobProvider.getIndustry());
            stmt.setString(4, jobProvider.getWebsite());
            stmt.setString(5, jobProvider.getLocation());
            stmt.setInt(6, jobProvider.getId());
            
            rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Updating job provider details failed, no rows affected.");
            }
            
            conn.commit();
            return true;
        } catch (SQLException | ClassNotFoundException e) {
            // Rollback transaction if error occurs
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new SQLException("Rollback failed", ex);
                }
            }
            throw new SQLException("Error updating job provider", e);
        } finally {
            // Close resources and reset auto-commit
            if (stmt != null) try { stmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { /* ignored */ }
            }
        }
    }
    
    /**
     * Updates an Administrator in the database
     * 
     * @param admin The Administrator to update
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateAdmin(Administrator admin) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);
            
            // Update users table
            String userSql = "UPDATE users SET email = ?, full_name = ?, phone = ?, is_active = ? " +
                             "WHERE id = ? AND user_type = ?";
            
            stmt = conn.prepareStatement(userSql);
            stmt.setString(1, admin.getEmail());
            stmt.setString(2, admin.getFullName());
            stmt.setString(3, admin.getPhone());
            stmt.setBoolean(4, admin.isActive());
            stmt.setInt(5, admin.getId());
            stmt.setInt(6, User.ADMINISTRATOR);
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Updating user failed, no rows affected.");
            }
            
            // Update administrators table
            String adminSql = "UPDATE administrators SET role = ?, department = ?, access_level = ? " +
                              "WHERE user_id = ?";
            
            stmt = conn.prepareStatement(adminSql);
            stmt.setString(1, admin.getRole());
            stmt.setString(2, admin.getDepartment());
            stmt.setInt(3, admin.getAccessLevel());
            stmt.setInt(4, admin.getId());
            
            rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Updating administrator details failed, no rows affected.");
            }
            
            conn.commit();
            return true;
        } catch (SQLException | ClassNotFoundException e) {
            // Rollback transaction if error occurs
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new SQLException("Rollback failed", ex);
                }
            }
            throw new SQLException("Error updating administrator", e);
        } finally {
            // Close resources and reset auto-commit
            if (stmt != null) try { stmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { /* ignored */ }
            }
        }
    }
    
    /**
     * Deletes a user from the database
     * 
     * @param userId The ID of the user to delete
     * @param userType The type of the user
     * @return true if deletion was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean deleteUser(int userId, int userType) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);
            
            // Delete from specific user type table
            String specificSql = "";
            switch (userType) {
                case User.JOB_SEEKER:
                    specificSql = "DELETE FROM job_seekers WHERE user_id = ?";
                    break;
                case User.JOB_PROVIDER:
                    specificSql = "DELETE FROM job_providers WHERE user_id = ?";
                    break;
                case User.ADMINISTRATOR:
                    specificSql = "DELETE FROM administrators WHERE user_id = ?";
                    break;
                default:
                    throw new SQLException("Invalid user type: " + userType);
            }
            
            stmt = conn.prepareStatement(specificSql);
            stmt.setInt(1, userId);
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected == 0) {
                throw new SQLException("Deleting user specific details failed, no rows affected.");
            }
            
            // Delete from users table
            String userSql = "DELETE FROM users WHERE id = ? AND user_type = ?";
            stmt = conn.prepareStatement(userSql);
            stmt.setInt(1, userId);
            stmt.setInt(2, userType);
            rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected == 0) {
                throw new SQLException("Deleting user failed, no rows affected.");
            }
            
            conn.commit();
            return true;
        } catch (SQLException | ClassNotFoundException e) {
            // Rollback transaction if error occurs
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new SQLException("Rollback failed", ex);
                }
            }
            throw new SQLException("Error deleting user", e);
        } finally {
            // Close resources and reset auto-commit
            if (stmt != null) try { stmt.close(); } catch (SQLException e) { /* ignored */ }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { /* ignored */ }
            }
        }
    }
    
    /**
     * Checks if a username is already taken
     * 
     * @param username The username to check
     * @return true if the username is taken, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean isUsernameTaken(String username) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
                return false;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Checks if an email is already taken
     * 
     * @param email The email to check
     * @return true if the email is taken, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean isEmailTaken(String email) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
                return false;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Get all job seekers
     * 
     * @return List of all JobSeeker objects
     * @throws SQLException If a database error occurs
     */
    public List<JobSeeker> getAllJobSeekers() throws SQLException {
        List<JobSeeker> jobSeekers = new ArrayList<>();
        String sql = "SELECT u.*, js.resume, js.skills, js.education, js.experience, js.preferences " +
                     "FROM users u " +
                     "JOIN job_seekers js ON u.id = js.user_id " +
                     "WHERE u.user_type = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, User.JOB_SEEKER);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    jobSeekers.add(extractJobSeekerFromResultSet(rs));
                }
                return jobSeekers;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Get all job providers
     * 
     * @return List of all JobProvider objects
     * @throws SQLException If a database error occurs
     */
    public List<JobProvider> getAllJobProviders() throws SQLException {
        List<JobProvider> jobProviders = new ArrayList<>();
        String sql = "SELECT u.*, jp.company_name, jp.company_description, jp.industry, jp.website, jp.location " +
                     "FROM users u " +
                     "JOIN job_providers jp ON u.id = jp.user_id " +
                     "WHERE u.user_type = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, User.JOB_PROVIDER);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    jobProviders.add(extractJobProviderFromResultSet(rs));
                }
                return jobProviders;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Extracts a JobSeeker object from a ResultSet
     * 
     * @param rs The ResultSet containing job seeker data
     * @return A JobSeeker object
     * @throws SQLException If a database error occurs
     */
    private JobSeeker extractJobSeekerFromResultSet(ResultSet rs) throws SQLException {
        JobSeeker jobSeeker = new JobSeeker();
        
        // Set basic user properties
        jobSeeker.setId(rs.getInt("id"));
        jobSeeker.setUsername(rs.getString("username"));
        jobSeeker.setPassword(rs.getString("password"));
        jobSeeker.setEmail(rs.getString("email"));
        jobSeeker.setFullName(rs.getString("full_name"));
        jobSeeker.setPhone(rs.getString("phone"));
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            jobSeeker.setCreatedAt(createdAt.toLocalDateTime());
        }
        
        Timestamp lastLogin = rs.getTimestamp("last_login");
        if (lastLogin != null) {
            jobSeeker.setLastLogin(lastLogin.toLocalDateTime());
        }
        
        jobSeeker.setActive(rs.getBoolean("is_active"));
        
        // Set job seeker specific properties
        jobSeeker.setResume(rs.getString("resume"));
        jobSeeker.setSkills(rs.getString("skills"));
        jobSeeker.setEducation(rs.getString("education"));
        jobSeeker.setExperience(rs.getString("experience"));
        jobSeeker.setPreferences(rs.getString("preferences"));
        
        return jobSeeker;
    }
    
    /**
     * Extracts a JobProvider object from a ResultSet
     * 
     * @param rs The ResultSet containing job provider data
     * @return A JobProvider object
     * @throws SQLException If a database error occurs
     */
    private JobProvider extractJobProviderFromResultSet(ResultSet rs) throws SQLException {
        JobProvider jobProvider = new JobProvider();
        
        // Set basic user properties
        jobProvider.setId(rs.getInt("id"));
        jobProvider.setUsername(rs.getString("username"));
        jobProvider.setPassword(rs.getString("password"));
        jobProvider.setEmail(rs.getString("email"));
        jobProvider.setFullName(rs.getString("full_name"));
        jobProvider.setPhone(rs.getString("phone"));
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            jobProvider.setCreatedAt(createdAt.toLocalDateTime());
        }
        
        Timestamp lastLogin = rs.getTimestamp("last_login");
        if (lastLogin != null) {
            jobProvider.setLastLogin(lastLogin.toLocalDateTime());
        }
        
        jobProvider.setActive(rs.getBoolean("is_active"));
        
        // Set job provider specific properties
        jobProvider.setCompanyName(rs.getString("company_name"));
        jobProvider.setCompanyDescription(rs.getString("company_description"));
        jobProvider.setIndustry(rs.getString("industry"));
        jobProvider.setWebsite(rs.getString("website"));
        jobProvider.setLocation(rs.getString("location"));
        
        return jobProvider;
    }
    
    /**
     * Extracts an Administrator object from a ResultSet
     * 
     * @param rs The ResultSet containing administrator data
     * @return An Administrator object
     * @throws SQLException If a database error occurs
     */
    private Administrator extractAdminFromResultSet(ResultSet rs) throws SQLException {
        Administrator admin = new Administrator();
        
        // Set basic user properties
        admin.setId(rs.getInt("id"));
        admin.setUsername(rs.getString("username"));
        admin.setPassword(rs.getString("password"));
        admin.setEmail(rs.getString("email"));
        admin.setFullName(rs.getString("full_name"));
        admin.setPhone(rs.getString("phone"));
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            admin.setCreatedAt(createdAt.toLocalDateTime());
        }
        
        Timestamp lastLogin = rs.getTimestamp("last_login");
        if (lastLogin != null) {
            admin.setLastLogin(lastLogin.toLocalDateTime());
        }
        
        admin.setActive(rs.getBoolean("is_active"));
        
        // Set administrator specific properties
        admin.setRole(rs.getString("role"));
        admin.setDepartment(rs.getString("department"));
        admin.setAccessLevel(rs.getInt("access_level"));
        
        return admin;
    }
}
