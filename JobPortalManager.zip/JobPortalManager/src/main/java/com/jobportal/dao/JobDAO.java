package com.jobportal.dao;

import com.jobportal.model.Job;
import com.jobportal.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Job-related database operations.
 * Handles CRUD operations for job listings.
 */
public class JobDAO {
    
    /**
     * Creates a new job posting in the database
     * 
     * @param job The Job to create
     * @return The created Job with ID assigned, or null if creation failed
     * @throws SQLException If a database error occurs
     */
    public Job createJob(Job job) throws SQLException {
        String sql = "INSERT INTO jobs (provider_id, title, description, requirements, responsibilities, " +
                    "location, type, category, salary, deadline_date, created_at, updated_at, is_active) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, job.getProviderId());
            stmt.setString(2, job.getTitle());
            stmt.setString(3, job.getDescription());
            stmt.setString(4, job.getRequirements());
            stmt.setString(5, job.getResponsibilities());
            stmt.setString(6, job.getLocation());
            stmt.setString(7, job.getType());
            stmt.setString(8, job.getCategory());
            stmt.setDouble(9, job.getSalary());
            stmt.setDate(10, job.getDeadlineDate() != null ? Date.valueOf(job.getDeadlineDate()) : null);
            stmt.setTimestamp(11, Timestamp.valueOf(job.getCreatedAt()));
            stmt.setTimestamp(12, Timestamp.valueOf(job.getUpdatedAt()));
            stmt.setBoolean(13, job.isActive());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        job.setId(generatedKeys.getInt(1));
                        return job;
                    }
                }
            }
            
            return null;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Retrieves a job by its ID
     * 
     * @param jobId The ID of the job to retrieve
     * @return The Job object, or null if not found
     * @throws SQLException If a database error occurs
     */
    public Job getJobById(int jobId) throws SQLException {
        String sql = "SELECT * FROM jobs WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, jobId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractJobFromResultSet(rs);
                }
                return null;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Updates a job in the database
     * 
     * @param job The Job to update
     * @return true if update was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean updateJob(Job job) throws SQLException {
        String sql = "UPDATE jobs SET title = ?, description = ?, requirements = ?, responsibilities = ?, " +
                    "location = ?, type = ?, category = ?, salary = ?, deadline_date = ?, " +
                    "updated_at = ?, is_active = ? WHERE id = ? AND provider_id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, job.getTitle());
            stmt.setString(2, job.getDescription());
            stmt.setString(3, job.getRequirements());
            stmt.setString(4, job.getResponsibilities());
            stmt.setString(5, job.getLocation());
            stmt.setString(6, job.getType());
            stmt.setString(7, job.getCategory());
            stmt.setDouble(8, job.getSalary());
            stmt.setDate(9, job.getDeadlineDate() != null ? Date.valueOf(job.getDeadlineDate()) : null);
            
            // Update the timestamp before saving
            job.updateTimestamp();
            stmt.setTimestamp(10, Timestamp.valueOf(job.getUpdatedAt()));
            stmt.setBoolean(11, job.isActive());
            stmt.setInt(12, job.getId());
            stmt.setInt(13, job.getProviderId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Deletes a job from the database
     * 
     * @param jobId The ID of the job to delete
     * @param providerId The ID of the provider who owns the job
     * @return true if deletion was successful, false otherwise
     * @throws SQLException If a database error occurs
     */
    public boolean deleteJob(int jobId, int providerId) throws SQLException {
        String sql = "DELETE FROM jobs WHERE id = ? AND provider_id = ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, jobId);
            stmt.setInt(2, providerId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets all jobs posted by a specific provider
     * 
     * @param providerId The ID of the provider
     * @return List of jobs posted by the provider
     * @throws SQLException If a database error occurs
     */
    public List<Job> getJobsByProvider(int providerId) throws SQLException {
        List<Job> jobs = new ArrayList<>();
        String sql = "SELECT * FROM jobs WHERE provider_id = ? ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, providerId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    jobs.add(extractJobFromResultSet(rs));
                }
                return jobs;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Searches for jobs based on various criteria
     * 
     * @param title Optional job title to search for
     * @param location Optional job location to search for
     * @param type Optional job type to filter by
     * @param category Optional job category to filter by
     * @param minSalary Optional minimum salary to filter by
     * @return List of jobs matching the search criteria
     * @throws SQLException If a database error occurs
     */
    public List<Job> searchJobs(String title, String location, String type, String category, Double minSalary) throws SQLException {
        List<Job> jobs = new ArrayList<>();
        
        StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM jobs WHERE is_active = TRUE");
        List<Object> params = new ArrayList<>();
        
        // Add search conditions if provided
        if (title != null && !title.isEmpty()) {
            sqlBuilder.append(" AND title LIKE ?");
            params.add("%" + title + "%");
        }
        
        if (location != null && !location.isEmpty()) {
            sqlBuilder.append(" AND location LIKE ?");
            params.add("%" + location + "%");
        }
        
        if (type != null && !type.isEmpty()) {
            sqlBuilder.append(" AND type = ?");
            params.add(type);
        }
        
        if (category != null && !category.isEmpty()) {
            sqlBuilder.append(" AND category = ?");
            params.add(category);
        }
        
        if (minSalary != null) {
            sqlBuilder.append(" AND salary >= ?");
            params.add(minSalary);
        }
        
        // Add ordering
        sqlBuilder.append(" ORDER BY created_at DESC");
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sqlBuilder.toString())) {
            
            // Set parameters
            for (int i = 0; i < params.size(); i++) {
                Object param = params.get(i);
                if (param instanceof String) {
                    stmt.setString(i + 1, (String) param);
                } else if (param instanceof Double) {
                    stmt.setDouble(i + 1, (Double) param);
                }
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    jobs.add(extractJobFromResultSet(rs));
                }
                return jobs;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets recently posted active jobs
     * 
     * @param limit The maximum number of jobs to return
     * @return List of recent jobs
     * @throws SQLException If a database error occurs
     */
    public List<Job> getRecentJobs(int limit) throws SQLException {
        List<Job> jobs = new ArrayList<>();
        String sql = "SELECT * FROM jobs WHERE is_active = TRUE " +
                    "ORDER BY created_at DESC LIMIT ?";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, limit);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    jobs.add(extractJobFromResultSet(rs));
                }
                return jobs;
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets all job categories from the database
     * 
     * @return List of unique job categories
     * @throws SQLException If a database error occurs
     */
    public List<String> getAllJobCategories() throws SQLException {
        List<String> categories = new ArrayList<>();
        String sql = "SELECT DISTINCT category FROM jobs WHERE category IS NOT NULL AND category != '' ORDER BY category";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                categories.add(rs.getString("category"));
            }
            return categories;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Gets all job locations from the database
     * 
     * @return List of unique job locations
     * @throws SQLException If a database error occurs
     */
    public List<String> getAllJobLocations() throws SQLException {
        List<String> locations = new ArrayList<>();
        String sql = "SELECT DISTINCT location FROM jobs WHERE location IS NOT NULL AND location != '' ORDER BY location";
        
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                locations.add(rs.getString("location"));
            }
            return locations;
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }
    
    /**
     * Extracts a Job object from a ResultSet
     * 
     * @param rs The ResultSet containing job data
     * @return A Job object
     * @throws SQLException If a database error occurs
     */
    private Job extractJobFromResultSet(ResultSet rs) throws SQLException {
        Job job = new Job();
        
        job.setId(rs.getInt("id"));
        job.setProviderId(rs.getInt("provider_id"));
        job.setTitle(rs.getString("title"));
        job.setDescription(rs.getString("description"));
        job.setRequirements(rs.getString("requirements"));
        job.setResponsibilities(rs.getString("responsibilities"));
        job.setLocation(rs.getString("location"));
        job.setType(rs.getString("type"));
        job.setCategory(rs.getString("category"));
        job.setSalary(rs.getDouble("salary"));
        
        Date deadlineDate = rs.getDate("deadline_date");
        if (deadlineDate != null) {
            job.setDeadlineDate(deadlineDate.toLocalDate());
        }
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            job.setCreatedAt(createdAt.toLocalDateTime());
        }
        
        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) {
            job.setUpdatedAt(updatedAt.toLocalDateTime());
        }
        
        job.setActive(rs.getBoolean("is_active"));
        
        return job;
    }
}
