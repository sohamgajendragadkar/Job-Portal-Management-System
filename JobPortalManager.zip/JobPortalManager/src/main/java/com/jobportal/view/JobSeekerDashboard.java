package com.jobportal.view;

import com.jobportal.controller.ApplicationController;
import com.jobportal.controller.JobController;
import com.jobportal.controller.UserController;
import com.jobportal.model.Application;
import com.jobportal.model.Job;
import com.jobportal.model.JobSeeker;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Dashboard view for job seekers.
 * Provides access to job search, applications, and profile management.
 */
public class JobSeekerDashboard extends JFrame {
    private JobSeeker jobSeeker;
    private JobController jobController;
    private ApplicationController applicationController;
    private UserController userController;
    
    // UI Components
    private JPanel mainPanel;
    private JPanel contentPanel;
    private JLabel welcomeLabel;
    private JButton searchJobsButton;
    private JButton myApplicationsButton;
    private JButton profileButton;
    private JButton logoutButton;
    
    // Formatters
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
    private DecimalFormat salaryFormatter = new DecimalFormat("#,##0.00");
    
    /**
     * Constructor initializes the dashboard with user data
     * 
     * @param jobSeeker The logged-in job seeker
     */
    public JobSeekerDashboard(JobSeeker jobSeeker) {
        this.jobSeeker = jobSeeker;
        this.jobController = new JobController();
        this.applicationController = new ApplicationController();
        this.userController = new UserController();
        
        initializeUI();
        loadDashboardContent();
    }
    
    /**
     * Sets up the user interface
     */
    private void initializeUI() {
        // Configure the frame
        setTitle("Job Portal - Job Seeker Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null); // Center on screen
        
        // Create main panel
        mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create navigation panel (sidebar)
        JPanel navPanel = createNavigationPanel();
        mainPanel.add(navPanel, BorderLayout.WEST);
        
        // Create content panel
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Add the main panel to the frame
        add(mainPanel);
        
        // Set action listeners for navigation buttons
        searchJobsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openJobSearch();
            }
        });
        
        myApplicationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showMyApplications();
            }
        });
        
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openProfileView();
            }
        });
        
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });
    }
    
    /**
     * Creates the header panel
     * 
     * @return The header panel
     */
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(51, 102, 153));
        headerPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        
        welcomeLabel = new JLabel("Welcome, " + jobSeeker.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        
        headerPanel.add(welcomeLabel, BorderLayout.WEST);
        
        logoutButton = new JButton("Logout");
        headerPanel.add(logoutButton, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    /**
     * Creates the navigation panel (sidebar)
     * 
     * @return The navigation panel
     */
    private JPanel createNavigationPanel() {
        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBackground(new Color(240, 240, 240));
        navPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        navPanel.setPreferredSize(new Dimension(200, getHeight()));
        
        // Create navigation buttons
        searchJobsButton = createNavButton("Search Jobs");
        myApplicationsButton = createNavButton("My Applications");
        profileButton = createNavButton("My Profile");
        
        // Add buttons to panel
        navPanel.add(searchJobsButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(myApplicationsButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(profileButton);
        navPanel.add(Box.createVerticalGlue());
        
        return navPanel;
    }
    
    /**
     * Creates a styled navigation button
     * 
     * @param text The button text
     * @return The styled button
     */
    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, button.getPreferredSize().height));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        return button;
    }
    
    /**
     * Loads the initial dashboard content
     */
    private void loadDashboardContent() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create dashboard components
        JPanel dashboardPanel = new JPanel();
        dashboardPanel.setLayout(new BoxLayout(dashboardPanel, BoxLayout.Y_AXIS));
        
        // Add welcome section
        JPanel welcomePanel = new JPanel(new BorderLayout());
        JLabel dashboardTitle = new JLabel("Dashboard");
        dashboardTitle.setFont(new Font("Arial", Font.BOLD, 20));
        welcomePanel.add(dashboardTitle, BorderLayout.NORTH);
        
        // Add stats section if available
        JPanel statsPanel = createStatsPanel();
        
        // Add recent jobs section
        JPanel recentJobsPanel = createRecentJobsPanel();
        
        // Add content to dashboard
        dashboardPanel.add(welcomePanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(statsPanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(recentJobsPanel);
        
        // Add dashboard to content panel with scroll pane
        JScrollPane scrollPane = new JScrollPane(dashboardPanel);
        scrollPane.setBorder(null);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Creates the statistics panel for the dashboard
     * 
     * @return The statistics panel
     */
    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new BorderLayout());
        statsPanel.setBorder(BorderFactory.createTitledBorder("My Statistics"));
        
        try {
            // Get application stats
            List<Application> applications = applicationController.getApplicationsBySeeker(jobSeeker.getId());
            
            // Create a panel for stats display
            JPanel statsContent = new JPanel(new GridLayout(1, 4, 10, 0));
            
            // Count different statuses
            int totalApplications = applications.size();
            int pendingCount = 0;
            int interviewCount = 0;
            int rejectedCount = 0;
            
            for (Application app : applications) {
                if (app.getStatus().equals(Application.STATUS_PENDING) || 
                    app.getStatus().equals(Application.STATUS_REVIEWING)) {
                    pendingCount++;
                } else if (app.getStatus().equals(Application.STATUS_INTERVIEW) || 
                           app.getStatus().equals(Application.STATUS_SHORTLISTED)) {
                    interviewCount++;
                } else if (app.getStatus().equals(Application.STATUS_REJECTED)) {
                    rejectedCount++;
                }
            }
            
            // Add stat cards
            statsContent.add(createStatCard("Total Applications", String.valueOf(totalApplications), new Color(51, 102, 153)));
            statsContent.add(createStatCard("Pending", String.valueOf(pendingCount), new Color(255, 193, 7)));
            statsContent.add(createStatCard("Interviews", String.valueOf(interviewCount), new Color(40, 167, 69)));
            statsContent.add(createStatCard("Rejected", String.valueOf(rejectedCount), new Color(220, 53, 69)));
            
            statsPanel.add(statsContent, BorderLayout.CENTER);
            
        } catch (Exception e) {
            statsPanel.add(new JLabel("Error loading statistics: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return statsPanel;
    }
    
    /**
     * Creates a statistic card for the dashboard
     * 
     * @param title The stat title
     * @param value The stat value
     * @param color The background color
     * @return The stat card panel
     */
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(color);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(titleLabel, BorderLayout.SOUTH);
        
        return card;
    }
    
    /**
     * Creates the recent jobs panel for the dashboard
     * 
     * @return The recent jobs panel
     */
    private JPanel createRecentJobsPanel() {
        JPanel recentJobsPanel = new JPanel(new BorderLayout());
        recentJobsPanel.setBorder(BorderFactory.createTitledBorder("Recently Posted Jobs"));
        
        try {
            // Get recent jobs
            List<Job> recentJobs = jobController.getRecentJobs(5);
            
            if (recentJobs.isEmpty()) {
                recentJobsPanel.add(new JLabel("No jobs available at the moment."), BorderLayout.CENTER);
            } else {
                // Create a panel for jobs list
                JPanel jobsListPanel = new JPanel();
                jobsListPanel.setLayout(new BoxLayout(jobsListPanel, BoxLayout.Y_AXIS));
                
                for (Job job : recentJobs) {
                    JPanel jobCard = createJobCard(job);
                    jobsListPanel.add(jobCard);
                    jobsListPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                }
                
                // Add view all button
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton viewAllButton = new JButton("View All Jobs");
                viewAllButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        openJobSearch();
                    }
                });
                buttonPanel.add(viewAllButton);
                
                recentJobsPanel.add(jobsListPanel, BorderLayout.CENTER);
                recentJobsPanel.add(buttonPanel, BorderLayout.SOUTH);
            }
            
        } catch (Exception e) {
            recentJobsPanel.add(new JLabel("Error loading recent jobs: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return recentJobsPanel;
    }
    
    /**
     * Creates a job card for the jobs list
     * 
     * @param job The job to display
     * @return The job card panel
     */
    private JPanel createJobCard(Job job) {
        JPanel card = new JPanel(new BorderLayout(10, 5));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Job title
        JLabel titleLabel = new JLabel(job.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        // Job details
        JPanel detailsPanel = new JPanel(new GridLayout(3, 1));
        
        JLabel locationLabel = new JLabel("📍 " + job.getLocation());
        JLabel typeLabel = new JLabel("⏱ " + job.getType());
        JLabel salaryLabel = new JLabel("💰 $" + salaryFormatter.format(job.getSalary()) + " per year");
        
        detailsPanel.add(locationLabel);
        detailsPanel.add(typeLabel);
        detailsPanel.add(salaryLabel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton viewButton = new JButton("View Details");
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showJobDetails(job);
            }
        });
        buttonPanel.add(viewButton);
        
        // Add components to card
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(detailsPanel, BorderLayout.CENTER);
        card.add(buttonPanel, BorderLayout.SOUTH);
        
        return card;
    }
    
    /**
     * Opens the job search view
     */
    private void openJobSearch() {
        JobSearchView jobSearchView = new JobSearchView(this, jobSeeker);
        setContentPanel(jobSearchView.getContentPanel());
    }
    
    /**
     * Shows the job details
     * 
     * @param job The job to display
     */
    private void showJobDetails(Job job) {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create job details panel
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
        
        // Create header with back button
        JPanel headerPanel = new JPanel(new BorderLayout());
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadDashboardContent();
            }
        });
        
        headerPanel.add(backButton, BorderLayout.WEST);
        detailsPanel.add(headerPanel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Job title
        JLabel titleLabel = new JLabel(job.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        detailsPanel.add(titleLabel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        
        // Company and location
        JPanel subheaderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        subheaderPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        subheaderPanel.setBackground(getBackground());
        
        // We need to fetch company name
        String companyName = "Company";
        try {
            companyName = userController.getJobProviderById(job.getProviderId()).getCompanyName();
        } catch (Exception e) {
            // Use default if error
        }
        
        JLabel companyLabel = new JLabel(companyName + " • " + job.getLocation());
        companyLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subheaderPanel.add(companyLabel);
        
        detailsPanel.add(subheaderPanel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Job details panel
        JPanel infoPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        infoPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Job type
        JPanel typePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        typePanel.add(new JLabel("Job Type: " + job.getType()));
        
        // Salary
        JPanel salaryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        salaryPanel.add(new JLabel("Salary: $" + salaryFormatter.format(job.getSalary())));
        
        // Deadline
        JPanel deadlinePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        String deadlineText = job.getDeadlineDate() != null ? 
                             "Deadline: " + job.getDeadlineDate().format(dateFormatter) : 
                             "No deadline specified";
        deadlinePanel.add(new JLabel(deadlineText));
        
        infoPanel.add(typePanel);
        infoPanel.add(salaryPanel);
        infoPanel.add(deadlinePanel);
        detailsPanel.add(infoPanel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Description
        JPanel descriptionPanel = createSectionPanel("Job Description", job.getDescription());
        detailsPanel.add(descriptionPanel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Requirements
        JPanel requirementsPanel = createSectionPanel("Requirements", job.getRequirements());
        detailsPanel.add(requirementsPanel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Responsibilities
        JPanel responsibilitiesPanel = createSectionPanel("Responsibilities", job.getResponsibilities());
        detailsPanel.add(responsibilitiesPanel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Apply button
        JPanel applyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton applyButton = new JButton("Apply for this Job");
        
        // Check if already applied
        boolean alreadyApplied = applicationController.hasAppliedToJob(job.getId(), jobSeeker.getId());
        
        if (alreadyApplied) {
            applyButton.setText("Already Applied");
            applyButton.setEnabled(false);
        }
        
        applyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showApplicationForm(job);
            }
        });
        
        applyPanel.add(applyButton);
        detailsPanel.add(applyPanel);
        
        // Add to scroll pane
        JScrollPane scrollPane = new JScrollPane(detailsPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        
        // Add to content panel
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Creates a section panel for job details
     * 
     * @param title The section title
     * @param content The section content
     * @return The section panel
     */
    private JPanel createSectionPanel(String title, String content) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JTextArea contentArea = new JTextArea(content != null ? content : "No information provided");
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setEditable(false);
        contentArea.setBackground(null);
        contentArea.setBorder(null);
        contentArea.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.add(contentArea);
        
        return panel;
    }
    
    /**
     * Shows the application form for a job
     * 
     * @param job The job to apply for
     */
    private void showApplicationForm(Job job) {
        // Create application dialog
        JDialog applicationDialog = new JDialog(this, "Apply for " + job.getTitle(), true);
        applicationDialog.setSize(600, 500);
        applicationDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Form title
        JLabel titleLabel = new JLabel("Apply for: " + job.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        // Form fields
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        
        // Cover letter
        JLabel coverLetterLabel = new JLabel("Cover Letter:");
        coverLetterLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JTextArea coverLetterArea = new JTextArea(10, 30);
        coverLetterArea.setLineWrap(true);
        coverLetterArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(coverLetterArea);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        formPanel.add(coverLetterLabel);
        formPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        formPanel.add(scrollPane);
        formPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Resume section - show current resume or allow input
        JLabel resumeLabel = new JLabel("Resume/CV:");
        resumeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JTextArea resumeArea = new JTextArea(10, 30);
        resumeArea.setLineWrap(true);
        resumeArea.setWrapStyleWord(true);
        
        // Pre-fill with existing resume if available
        if (jobSeeker.getResume() != null && !jobSeeker.getResume().isEmpty()) {
            resumeArea.setText(jobSeeker.getResume());
        }
        
        JScrollPane resumeScrollPane = new JScrollPane(resumeArea);
        resumeScrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        formPanel.add(resumeLabel);
        formPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        formPanel.add(resumeScrollPane);
        
        // Add form to panel
        panel.add(formPanel, BorderLayout.CENTER);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton cancelButton = new JButton("Cancel");
        JButton submitButton = new JButton("Submit Application");
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                applicationDialog.dispose();
            }
        });
        
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validate form
                if (coverLetterArea.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(applicationDialog,
                        "Please provide a cover letter.",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (resumeArea.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(applicationDialog,
                        "Please provide your resume/CV.",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Create application
                Application application = new Application(job.getId(), jobSeeker.getId(), coverLetterArea.getText());
                
                // Update resume if changed
                if (!resumeArea.getText().equals(jobSeeker.getResume())) {
                    jobSeeker.setResume(resumeArea.getText());
                    userController.updateJobSeekerProfile(jobSeeker);
                }
                
                // Submit application
                Application result = applicationController.applyForJob(application);
                
                if (result != null) {
                    JOptionPane.showMessageDialog(applicationDialog,
                        "Your application has been submitted successfully!",
                        "Application Submitted",
                        JOptionPane.INFORMATION_MESSAGE);
                    applicationDialog.dispose();
                    
                    // Refresh job details to show "Already Applied"
                    showJobDetails(job);
                } else {
                    JOptionPane.showMessageDialog(applicationDialog,
                        "Failed to submit application. Please try again later.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(submitButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        applicationDialog.add(panel);
        applicationDialog.setVisible(true);
    }
    
    /**
     * Shows the user's applications
     */
    private void showMyApplications() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create applications panel
        JPanel applicationsPanel = new JPanel(new BorderLayout(0, 10));
        
        // Create header
        JLabel headerLabel = new JLabel("My Applications");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        applicationsPanel.add(headerLabel, BorderLayout.NORTH);
        
        try {
            // Get applications with job details
            List<Object[]> applications = applicationController.getApplicationsWithJobDetails(jobSeeker.getId());
            
            if (applications.isEmpty()) {
                JLabel emptyLabel = new JLabel("You haven't applied to any jobs yet.");
                emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
                applicationsPanel.add(emptyLabel, BorderLayout.CENTER);
            } else {
                // Create list panel
                JPanel listPanel = new JPanel();
                listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
                
                for (Object[] appData : applications) {
                    Application application = (Application) appData[0];
                    Job job = (Job) appData[1];
                    String companyName = (String) appData[2];
                    
                    JPanel appCard = createApplicationCard(application, job, companyName);
                    listPanel.add(appCard);
                    listPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                }
                
                // Add to scroll pane
                JScrollPane scrollPane = new JScrollPane(listPanel);
                scrollPane.setBorder(null);
                scrollPane.getVerticalScrollBar().setUnitIncrement(16);
                
                applicationsPanel.add(scrollPane, BorderLayout.CENTER);
            }
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading applications: " + e.getMessage());
            errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
            applicationsPanel.add(errorLabel, BorderLayout.CENTER);
        }
        
        // Add to content panel
        contentPanel.add(applicationsPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Creates an application card for the applications list
     * 
     * @param application The application data
     * @param job The associated job
     * @param companyName The company name
     * @return The application card panel
     */
    private JPanel createApplicationCard(Application application, Job job, String companyName) {
        JPanel card = new JPanel(new BorderLayout(10, 5));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Job title and company
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel(job.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        JLabel companyLabel = new JLabel(companyName);
        companyLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(companyLabel, BorderLayout.SOUTH);
        
        // Application details
        JPanel detailsPanel = new JPanel(new GridLayout(3, 1));
        
        // Format applied date
        String appliedDate = application.getAppliedAt().format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
        
        JLabel appliedLabel = new JLabel("Applied on: " + appliedDate);
        JLabel statusLabel = new JLabel("Status: " + application.getStatus());
        
        // Style status label based on status
        switch (application.getStatus()) {
            case Application.STATUS_PENDING:
            case Application.STATUS_REVIEWING:
                statusLabel.setForeground(new Color(255, 193, 7)); // Yellow
                break;
            case Application.STATUS_SHORTLISTED:
            case Application.STATUS_INTERVIEW:
            case Application.STATUS_OFFERED:
                statusLabel.setForeground(new Color(40, 167, 69)); // Green
                break;
            case Application.STATUS_HIRED:
                statusLabel.setForeground(new Color(0, 123, 255)); // Blue
                break;
            case Application.STATUS_REJECTED:
                statusLabel.setForeground(new Color(220, 53, 69)); // Red
                break;
            case Application.STATUS_WITHDRAWN:
                statusLabel.setForeground(Color.GRAY);
                break;
        }
        
        JLabel typeLocationLabel = new JLabel(job.getType() + " • " + job.getLocation());
        
        detailsPanel.add(appliedLabel);
        detailsPanel.add(statusLabel);
        detailsPanel.add(typeLocationLabel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        // View button
        JButton viewButton = new JButton("View");
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showApplicationDetails(application, job, companyName);
            }
        });
        
        // Withdraw button (only available for pending/reviewing applications)
        if (application.getStatus().equals(Application.STATUS_PENDING) ||
            application.getStatus().equals(Application.STATUS_REVIEWING)) {
            
            JButton withdrawButton = new JButton("Withdraw");
            withdrawButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    withdrawApplication(application);
                }
            });
            
            buttonPanel.add(withdrawButton);
        }
        
        buttonPanel.add(viewButton);
        
        // Add components to card
        card.add(titlePanel, BorderLayout.NORTH);
        card.add(detailsPanel, BorderLayout.CENTER);
        card.add(buttonPanel, BorderLayout.SOUTH);
        
        return card;
    }
    
    /**
     * Shows the application details
     * 
     * @param application The application to display
     * @param job The associated job
     * @param companyName The company name
     */
    private void showApplicationDetails(Application application, Job job, String companyName) {
        // Create dialog
        JDialog detailsDialog = new JDialog(this, "Application Details", true);
        detailsDialog.setSize(600, 500);
        detailsDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Application info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        
        // Job title
        JLabel titleLabel = new JLabel(job.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Company
        JLabel companyLabel = new JLabel(companyName);
        companyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
        companyLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Status with colored background
        JPanel statusPanel = new JPanel();
        statusPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel statusLabel = new JLabel(application.getStatus());
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        statusLabel.setForeground(Color.WHITE);
        statusPanel.add(statusLabel);
        
        // Set background color based on status
        switch (application.getStatus()) {
            case Application.STATUS_PENDING:
            case Application.STATUS_REVIEWING:
                statusPanel.setBackground(new Color(255, 193, 7)); // Yellow
                break;
            case Application.STATUS_SHORTLISTED:
            case Application.STATUS_INTERVIEW:
            case Application.STATUS_OFFERED:
                statusPanel.setBackground(new Color(40, 167, 69)); // Green
                break;
            case Application.STATUS_HIRED:
                statusPanel.setBackground(new Color(0, 123, 255)); // Blue
                break;
            case Application.STATUS_REJECTED:
                statusPanel.setBackground(new Color(220, 53, 69)); // Red
                break;
            case Application.STATUS_WITHDRAWN:
                statusPanel.setBackground(Color.GRAY);
                break;
        }
        
        // Applied date
        JLabel appliedLabel = new JLabel("Applied on: " + 
            application.getAppliedAt().format(DateTimeFormatter.ofPattern("dd MMMM yyyy")));
        appliedLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Add components to info panel
        infoPanel.add(titleLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        infoPanel.add(companyLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        infoPanel.add(statusPanel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        infoPanel.add(appliedLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Add notes if available
        if (application.getNotes() != null && !application.getNotes().isEmpty()) {
            JLabel notesLabel = new JLabel("Employer Notes:");
            notesLabel.setFont(new Font("Arial", Font.BOLD, 14));
            notesLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            JTextArea notesArea = new JTextArea(application.getNotes());
            notesArea.setLineWrap(true);
            notesArea.setWrapStyleWord(true);
            notesArea.setEditable(false);
            notesArea.setBackground(new Color(245, 245, 245));
            notesArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            JScrollPane notesScroll = new JScrollPane(notesArea);
            notesScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
            notesScroll.setPreferredSize(new Dimension(550, 80));
            
            infoPanel.add(notesLabel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            infoPanel.add(notesScroll);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        }
        
        // Cover letter
        JLabel coverLetterLabel = new JLabel("Your Cover Letter:");
        coverLetterLabel.setFont(new Font("Arial", Font.BOLD, 14));
        coverLetterLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JTextArea coverLetterArea = new JTextArea(application.getCoverLetter());
        coverLetterArea.setLineWrap(true);
        coverLetterArea.setWrapStyleWord(true);
        coverLetterArea.setEditable(false);
        
        JScrollPane coverLetterScroll = new JScrollPane(coverLetterArea);
        coverLetterScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        infoPanel.add(coverLetterLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        infoPanel.add(coverLetterScroll);
        
        // Add info panel to main panel
        panel.add(infoPanel, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        // Withdraw button (only available for pending/reviewing applications)
        if (application.getStatus().equals(Application.STATUS_PENDING) ||
            application.getStatus().equals(Application.STATUS_REVIEWING)) {
            
            JButton withdrawButton = new JButton("Withdraw Application");
            withdrawButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (withdrawApplication(application)) {
                        detailsDialog.dispose();
                    }
                }
            });
            
            buttonPanel.add(withdrawButton);
        }
        
        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                detailsDialog.dispose();
            }
        });
        
        buttonPanel.add(closeButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        detailsDialog.add(panel);
        detailsDialog.setVisible(true);
    }
    
    /**
     * Withdraws an application
     * 
     * @param application The application to withdraw
     * @return true if withdrawal was successful, false otherwise
     */
    private boolean withdrawApplication(Application application) {
        // Ask for confirmation
        int result = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to withdraw this application?",
            "Confirm Withdrawal",
            JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            boolean success = applicationController.withdrawApplication(application.getId(), jobSeeker.getId());
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Your application has been withdrawn.",
                    "Application Withdrawn",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh applications view
                showMyApplications();
                return true;
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to withdraw application. Please try again later.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        
        return false;
    }
    
    /**
     * Opens the profile view
     */
    private void openProfileView() {
        // Refresh job seeker data
        jobSeeker = userController.getJobSeekerById(jobSeeker.getId());
        
        // Create profile view
        ProfileView profileView = new ProfileView(this, jobSeeker);
        setContentPanel(profileView.getContentPanel());
    }
    
    /**
     * Sets the content of the content panel
     * 
     * @param newContent The new content panel
     */
    public void setContentPanel(JPanel newContent) {
        contentPanel.removeAll();
        contentPanel.add(newContent, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Refreshes the job seeker data
     * 
     * @param updatedSeeker The updated job seeker data
     */
    public void updateJobSeeker(JobSeeker updatedSeeker) {
        this.jobSeeker = updatedSeeker;
        welcomeLabel.setText("Welcome, " + jobSeeker.getFullName());
    }
    
    /**
     * Logs out the user
     */
    private void logout() {
        int result = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            dispose();
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
        }
    }
    
    /**
     * Gets the job seeker
     * 
     * @return The job seeker
     */
    public JobSeeker getJobSeeker() {
        return jobSeeker;
    }
}
