package com.jobportal.view;

import com.jobportal.controller.AuthController;
import com.jobportal.model.Administrator;
import com.jobportal.model.JobProvider;
import com.jobportal.model.JobSeeker;
import com.jobportal.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The login view for the application.
 * Provides login functionality and navigation to registration.
 */
public class LoginView extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerSeekerButton;
    private JButton registerProviderButton;
    private AuthController authController;
    
    /**
     * Constructor that initializes the login view
     */
    public LoginView() {
        authController = new AuthController();
        initializeUI();
    }
    
    /**
     * Sets up the user interface
     */
    private void initializeUI() {
        // Configure the frame
        setTitle("Job Portal - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null); // Center on screen
        
        // Create the main panel with some padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Create a panel for the title
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("Job Portal Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titlePanel.add(titleLabel);
        
        // Create the login form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 2, 10, 10));
        
        // Username field
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);
        formPanel.add(usernameLabel);
        formPanel.add(usernameField);
        
        // Password field
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        
        // Login button
        loginButton = new JButton("Login");
        formPanel.add(new JLabel("")); // Empty cell for alignment
        formPanel.add(loginButton);
        
        // Create a panel for the register buttons
        JPanel registerPanel = new JPanel();
        registerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JLabel registerLabel = new JLabel("Don't have an account?");
        registerSeekerButton = new JButton("Register as Job Seeker");
        registerProviderButton = new JButton("Register as Job Provider");
        
        registerPanel.add(registerLabel);
        registerPanel.add(registerSeekerButton);
        registerPanel.add(registerProviderButton);
        
        // Add the panels to the main panel
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(registerPanel, BorderLayout.SOUTH);
        
        // Add the main panel to the frame
        add(mainPanel);
        
        // Add action listeners
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performLogin();
            }
        });
        
        registerSeekerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openRegisterView(User.JOB_SEEKER);
            }
        });
        
        registerProviderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openRegisterView(User.JOB_PROVIDER);
            }
        });
    }
    
    /**
     * Handles the login process
     */
    private void performLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        // Validate input
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Username and password cannot be empty.",
                "Login Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Attempt to login
        User user = authController.login(username, password);
        
        if (user != null) {
            // Login successful
            openDashboard(user);
        } else {
            // Login failed
            JOptionPane.showMessageDialog(this,
                "Invalid username or password. Please try again.",
                "Login Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Opens the appropriate dashboard based on user type
     * 
     * @param user The authenticated user
     */
    private void openDashboard(User user) {
        // Close the login window
        dispose();
        
        // Open the appropriate dashboard
        switch (user.getUserType()) {
            case User.JOB_SEEKER:
                JobSeekerDashboard jobSeekerDashboard = new JobSeekerDashboard((JobSeeker) user);
                jobSeekerDashboard.setVisible(true);
                break;
                
            case User.JOB_PROVIDER:
                JobProviderDashboard jobProviderDashboard = new JobProviderDashboard((JobProvider) user);
                jobProviderDashboard.setVisible(true);
                break;
                
            case User.ADMINISTRATOR:
                AdminDashboard adminDashboard = new AdminDashboard((Administrator) user);
                adminDashboard.setVisible(true);
                break;
                
            default:
                JOptionPane.showMessageDialog(null,
                    "Unknown user type. Contact system administrator.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                // Reopen login screen
                LoginView loginView = new LoginView();
                loginView.setVisible(true);
        }
    }
    
    /**
     * Opens the registration view for a specific user type
     * 
     * @param userType The type of user to register
     */
    private void openRegisterView(int userType) {
        RegisterView registerView = new RegisterView(userType);
        registerView.setVisible(true);
        dispose(); // Close login window
    }
}
