package com.jobportal.view;

import com.jobportal.controller.AuthController;
import com.jobportal.model.JobProvider;
import com.jobportal.model.JobSeeker;
import com.jobportal.model.User;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.HashMap;
import java.util.Map;

/**
 * Registration view for new users.
 * Supports registration for both job seekers and job providers.
 */
public class RegisterView extends JFrame {
    private final int userType;
    private AuthController authController;
    
    // Common fields
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField emailField;
    private JTextField fullNameField;
    private JTextField phoneField;
    
    // Job seeker specific fields
    private JTextArea resumeArea;
    private JTextArea skillsArea;
    private JTextArea educationArea;
    private JTextArea experienceArea;
    private JTextArea preferencesArea;
    
    // Job provider specific fields
    private JTextField companyNameField;
    private JTextArea companyDescriptionArea;
    private JTextField industryField;
    private JTextField websiteField;
    private JTextField locationField;
    
    // Buttons
    private JButton registerButton;
    private JButton backButton;
    
    // Field validation map
    private Map<JTextComponent, Boolean> fieldValidMap = new HashMap<>();
    
    /**
     * Constructor initializes the registration view for a specific user type
     * 
     * @param userType The type of user (JOB_SEEKER or JOB_PROVIDER)
     */
    public RegisterView(int userType) {
        this.userType = userType;
        this.authController = new AuthController();
        initializeUI();
    }
    
    /**
     * Sets up the user interface based on user type
     */
    private void initializeUI() {
        // Configure the frame
        String title = "Register as " + (userType == User.JOB_SEEKER ? "Job Seeker" : "Job Provider");
        setTitle(title);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, userType == User.JOB_SEEKER ? 700 : 600);
        setLocationRelativeTo(null); // Center on screen
        
        // Main panel with some padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title panel
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titlePanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        
        // Add common fields
        formPanel.add(createFormSectionPanel("Account Information", createAccountInfoPanel()));
        formPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        formPanel.add(createFormSectionPanel("Personal Information", createPersonalInfoPanel()));
        formPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Add user type specific fields
        if (userType == User.JOB_SEEKER) {
            formPanel.add(createFormSectionPanel("Job Seeker Information", createSeekerInfoPanel()));
        } else {
            formPanel.add(createFormSectionPanel("Company Information", createProviderInfoPanel()));
        }
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        registerButton = new JButton("Register");
        backButton = new JButton("Back to Login");
        
        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);
        
        // Add panels to the main panel
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Wrap form panel in a scroll pane
        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Add the main panel to the frame
        add(mainPanel);
        
        // Add action listeners
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performRegistration();
            }
        });
        
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Return to login screen
                LoginView loginView = new LoginView();
                loginView.setVisible(true);
                dispose();
            }
        });
    }
    
    /**
     * Creates a panel for a form section with a title
     * 
     * @param title The section title
     * @param contentPanel The panel containing form fields
     * @return A panel containing the section
     */
    private JPanel createFormSectionPanel(String title, JPanel contentPanel) {
        JPanel sectionPanel = new JPanel();
        sectionPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        
        sectionPanel.add(titleLabel, BorderLayout.NORTH);
        sectionPanel.add(contentPanel, BorderLayout.CENTER);
        
        return sectionPanel;
    }
    
    /**
     * Creates the account information panel
     * 
     * @return Panel with account fields
     */
    private JPanel createAccountInfoPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        
        // Username field
        JLabel usernameLabel = new JLabel("Username*:");
        usernameField = new JTextField(20);
        panel.add(usernameLabel);
        panel.add(usernameField);
        
        // Password field
        JLabel passwordLabel = new JLabel("Password*:");
        passwordField = new JPasswordField(20);
        panel.add(passwordLabel);
        panel.add(passwordField);
        
        // Confirm password field
        JLabel confirmPasswordLabel = new JLabel("Confirm Password*:");
        confirmPasswordField = new JPasswordField(20);
        panel.add(confirmPasswordLabel);
        panel.add(confirmPasswordField);
        
        // Add validation for username field
        usernameField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                String username = usernameField.getText().trim();
                if (username.isEmpty()) {
                    showFieldError(usernameField, "Username is required");
                    fieldValidMap.put(usernameField, false);
                } else if (username.length() < 4) {
                    showFieldError(usernameField, "Username must be at least 4 characters");
                    fieldValidMap.put(usernameField, false);
                } else if (!authController.isUsernameAvailable(username)) {
                    showFieldError(usernameField, "Username is already taken");
                    fieldValidMap.put(usernameField, false);
                } else {
                    clearFieldError(usernameField);
                    fieldValidMap.put(usernameField, true);
                }
            }
        });
        
        return panel;
    }
    
    /**
     * Creates the personal information panel
     * 
     * @return Panel with personal info fields
     */
    private JPanel createPersonalInfoPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        
        // Email field
        JLabel emailLabel = new JLabel("Email*:");
        emailField = new JTextField(20);
        panel.add(emailLabel);
        panel.add(emailField);
        
        // Full name field
        JLabel fullNameLabel = new JLabel("Full Name*:");
        fullNameField = new JTextField(20);
        panel.add(fullNameLabel);
        panel.add(fullNameField);
        
        // Phone field
        JLabel phoneLabel = new JLabel("Phone Number*:");
        phoneField = new JTextField(20);
        panel.add(phoneLabel);
        panel.add(phoneField);
        
        // Add validation for email field
        emailField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                String email = emailField.getText().trim();
                if (email.isEmpty()) {
                    showFieldError(emailField, "Email is required");
                    fieldValidMap.put(emailField, false);
                } else if (!isValidEmail(email)) {
                    showFieldError(emailField, "Invalid email format");
                    fieldValidMap.put(emailField, false);
                } else if (!authController.isEmailAvailable(email)) {
                    showFieldError(emailField, "Email is already registered");
                    fieldValidMap.put(emailField, false);
                } else {
                    clearFieldError(emailField);
                    fieldValidMap.put(emailField, true);
                }
            }
        });
        
        return panel;
    }
    
    /**
     * Creates the job seeker specific information panel
     * 
     * @return Panel with job seeker fields
     */
    private JPanel createSeekerInfoPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        // Resume area
        panel.add(createTextAreaField("Resume/CV (optional):", createTextAreaWithScrollPane(resumeArea = new JTextArea(5, 40))));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Skills area
        panel.add(createTextAreaField("Skills (optional):", createTextAreaWithScrollPane(skillsArea = new JTextArea(3, 40))));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Education area
        panel.add(createTextAreaField("Education (optional):", createTextAreaWithScrollPane(educationArea = new JTextArea(3, 40))));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Experience area
        panel.add(createTextAreaField("Experience (optional):", createTextAreaWithScrollPane(experienceArea = new JTextArea(3, 40))));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Preferences area
        panel.add(createTextAreaField("Job Preferences (optional):", createTextAreaWithScrollPane(preferencesArea = new JTextArea(3, 40))));
        
        return panel;
    }
    
    /**
     * Creates the job provider specific information panel
     * 
     * @return Panel with job provider fields
     */
    private JPanel createProviderInfoPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        // Company name field
        JPanel companyNamePanel = new JPanel(new BorderLayout(5, 0));
        JLabel companyNameLabel = new JLabel("Company Name*:");
        companyNameField = new JTextField(40);
        companyNamePanel.add(companyNameLabel, BorderLayout.WEST);
        companyNamePanel.add(companyNameField, BorderLayout.CENTER);
        panel.add(companyNamePanel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Company description area
        panel.add(createTextAreaField("Company Description:", 
                createTextAreaWithScrollPane(companyDescriptionArea = new JTextArea(5, 40))));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Industry field
        JPanel industryPanel = new JPanel(new BorderLayout(5, 0));
        JLabel industryLabel = new JLabel("Industry*:");
        industryField = new JTextField(40);
        industryPanel.add(industryLabel, BorderLayout.WEST);
        industryPanel.add(industryField, BorderLayout.CENTER);
        panel.add(industryPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Website field
        JPanel websitePanel = new JPanel(new BorderLayout(5, 0));
        JLabel websiteLabel = new JLabel("Website (optional):");
        websiteField = new JTextField(40);
        websitePanel.add(websiteLabel, BorderLayout.WEST);
        websitePanel.add(websiteField, BorderLayout.CENTER);
        panel.add(websitePanel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Location field
        JPanel locationPanel = new JPanel(new BorderLayout(5, 0));
        JLabel locationLabel = new JLabel("Location*:");
        locationField = new JTextField(40);
        locationPanel.add(locationLabel, BorderLayout.WEST);
        locationPanel.add(locationField, BorderLayout.CENTER);
        panel.add(locationPanel);
        
        return panel;
    }
    
    /**
     * Creates a field with a text area and label
     * 
     * @param labelText The label text
     * @param component The text area component
     * @return A panel containing the field
     */
    private JPanel createTextAreaField(String labelText, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        JLabel label = new JLabel(labelText);
        panel.add(label, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }
    
    /**
     * Creates a scroll pane containing a text area
     * 
     * @param textArea The text area to wrap
     * @return A scroll pane containing the text area
     */
    private JScrollPane createTextAreaWithScrollPane(JTextArea textArea) {
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        return new JScrollPane(textArea);
    }
    
    /**
     * Shows an error message for a field
     * 
     * @param field The field with an error
     * @param message The error message
     */
    private void showFieldError(JTextComponent field, String message) {
        field.setBackground(new Color(255, 220, 220));
        field.setToolTipText(message);
    }
    
    /**
     * Clears error styling from a field
     * 
     * @param field The field to clear
     */
    private void clearFieldError(JTextComponent field) {
        field.setBackground(UIManager.getColor("TextField.background"));
        field.setToolTipText(null);
    }
    
    /**
     * Checks if an email is valid
     * 
     * @param email The email to validate
     * @return true if the email is valid, false otherwise
     */
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return email.matches(emailRegex);
    }
    
    /**
     * Handles the registration process
     */
    private void performRegistration() {
        // Validate common fields
        if (!validateCommonFields()) {
            return;
        }
        
        try {
            if (userType == User.JOB_SEEKER) {
                registerJobSeeker();
            } else {
                registerJobProvider();
            }
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this,
                e.getMessage(),
                "Registration Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Validates fields common to all user types
     * 
     * @return true if all fields are valid, false otherwise
     */
    private boolean validateCommonFields() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String email = emailField.getText().trim();
        String fullName = fullNameField.getText().trim();
        String phone = phoneField.getText().trim();
        
        // Check for empty fields
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || 
            email.isEmpty() || fullName.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please fill in all required fields.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Validate username
        if (username.length() < 4) {
            JOptionPane.showMessageDialog(this,
                "Username must be at least 4 characters long.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Check if username is available
        if (!authController.isUsernameAvailable(username)) {
            JOptionPane.showMessageDialog(this,
                "Username is already taken. Please choose another one.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Validate password
        if (password.length() < 6) {
            JOptionPane.showMessageDialog(this,
                "Password must be at least 6 characters long.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Check password confirmation
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                "Passwords do not match.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Validate email format
        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(this,
                "Please enter a valid email address.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Check if email is available
        if (!authController.isEmailAvailable(email)) {
            JOptionPane.showMessageDialog(this,
                "Email is already registered. Please use another email or login.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Validate phone number (basic check)
        if (phone.length() < 10) {
            JOptionPane.showMessageDialog(this,
                "Please enter a valid phone number.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    /**
     * Registers a job seeker
     */
    private void registerJobSeeker() {
        // Create job seeker object
        JobSeeker jobSeeker = new JobSeeker(
            usernameField.getText().trim(),
            new String(passwordField.getPassword()),
            emailField.getText().trim(),
            fullNameField.getText().trim(),
            phoneField.getText().trim()
        );
        
        // Set optional fields
        if (resumeArea.getText().trim().length() > 0) {
            jobSeeker.setResume(resumeArea.getText().trim());
        }
        
        if (skillsArea.getText().trim().length() > 0) {
            jobSeeker.setSkills(skillsArea.getText().trim());
        }
        
        if (educationArea.getText().trim().length() > 0) {
            jobSeeker.setEducation(educationArea.getText().trim());
        }
        
        if (experienceArea.getText().trim().length() > 0) {
            jobSeeker.setExperience(experienceArea.getText().trim());
        }
        
        if (preferencesArea.getText().trim().length() > 0) {
            jobSeeker.setPreferences(preferencesArea.getText().trim());
        }
        
        // Register the job seeker
        JobSeeker registeredSeeker = authController.registerJobSeeker(jobSeeker);
        
        if (registeredSeeker != null) {
            JOptionPane.showMessageDialog(this,
                "Registration successful! You can now login.",
                "Registration Complete",
                JOptionPane.INFORMATION_MESSAGE);
                
            // Return to login screen
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                "Registration failed. Please try again later.",
                "Registration Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Registers a job provider
     */
    private void registerJobProvider() {
        // Validate job provider specific fields
        String companyName = companyNameField.getText().trim();
        String industry = industryField.getText().trim();
        String location = locationField.getText().trim();
        
        if (companyName.isEmpty() || industry.isEmpty() || location.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Company name, industry, and location are required.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create job provider object
        JobProvider jobProvider = new JobProvider(
            usernameField.getText().trim(),
            new String(passwordField.getPassword()),
            emailField.getText().trim(),
            fullNameField.getText().trim(),
            phoneField.getText().trim()
        );
        
        // Set required fields
        jobProvider.setCompanyName(companyName);
        jobProvider.setIndustry(industry);
        jobProvider.setLocation(location);
        
        // Set optional fields
        if (companyDescriptionArea.getText().trim().length() > 0) {
            jobProvider.setCompanyDescription(companyDescriptionArea.getText().trim());
        }
        
        if (websiteField.getText().trim().length() > 0) {
            jobProvider.setWebsite(websiteField.getText().trim());
        }
        
        // Register the job provider
        JobProvider registeredProvider = authController.registerJobProvider(jobProvider);
        
        if (registeredProvider != null) {
            JOptionPane.showMessageDialog(this,
                "Registration successful! You can now login.",
                "Registration Complete",
                JOptionPane.INFORMATION_MESSAGE);
                
            // Return to login screen
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                "Registration failed. Please try again later.",
                "Registration Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}
