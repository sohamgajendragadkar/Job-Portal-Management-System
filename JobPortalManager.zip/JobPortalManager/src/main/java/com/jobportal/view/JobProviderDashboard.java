package com.jobportal.view;

import com.jobportal.controller.ApplicationController;
import com.jobportal.controller.JobController;
import com.jobportal.controller.UserController;
import com.jobportal.model.Application;
import com.jobportal.model.Job;
import com.jobportal.model.JobProvider;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Dashboard view for job providers.
 * Provides access to job management, applications, and profile management.
 */
public class JobProviderDashboard extends JFrame {
    private JobProvider jobProvider;
    private JobController jobController;
    private ApplicationController applicationController;
    private UserController userController;
    
    // UI Components
    private JPanel mainPanel;
    private JPanel contentPanel;
    private JLabel welcomeLabel;
    private JButton myJobsButton;
    private JButton postJobButton;
    private JButton applicationsButton;
    private JButton profileButton;
    private JButton logoutButton;
    
    // Formatters
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
    private DecimalFormat salaryFormatter = new DecimalFormat("#,##0.00");
    
    /**
     * Constructor initializes the dashboard with user data
     * 
     * @param jobProvider The logged-in job provider
     */
    public JobProviderDashboard(JobProvider jobProvider) {
        this.jobProvider = jobProvider;
        this.jobController = new JobController();
        this.applicationController = new ApplicationController();
        this.userController = new UserController();
        
        initializeUI();
        loadDashboardContent();
    }
    
    /**
     * Sets up the user interface
     */
    private void initializeUI() {
        // Configure the frame
        setTitle("Job Portal - Job Provider Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null); // Center on screen
        
        // Create main panel
        mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create navigation panel (sidebar)
        JPanel navPanel = createNavigationPanel();
        mainPanel.add(navPanel, BorderLayout.WEST);
        
        // Create content panel
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Add the main panel to the frame
        add(mainPanel);
        
        // Set action listeners for navigation buttons
        myJobsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showMyJobs();
            }
        });
        
        postJobButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openJobPostingView();
            }
        });
        
        applicationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showApplications();
            }
        });
        
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openProfileView();
            }
        });
        
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });
    }
    
    /**
     * Creates the header panel
     * 
     * @return The header panel
     */
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(51, 102, 153));
        headerPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        
        welcomeLabel = new JLabel("Welcome, " + jobProvider.getCompanyName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        
        headerPanel.add(welcomeLabel, BorderLayout.WEST);
        
        logoutButton = new JButton("Logout");
        headerPanel.add(logoutButton, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    /**
     * Creates the navigation panel (sidebar)
     * 
     * @return The navigation panel
     */
    private JPanel createNavigationPanel() {
        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBackground(new Color(240, 240, 240));
        navPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        navPanel.setPreferredSize(new Dimension(200, getHeight()));
        
        // Create navigation buttons
        myJobsButton = createNavButton("My Job Postings");
        postJobButton = createNavButton("Post New Job");
        applicationsButton = createNavButton("Applications");
        profileButton = createNavButton("Company Profile");
        
        // Add buttons to panel
        navPanel.add(myJobsButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(postJobButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(applicationsButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(profileButton);
        navPanel.add(Box.createVerticalGlue());
        
        return navPanel;
    }
    
    /**
     * Creates a styled navigation button
     * 
     * @param text The button text
     * @return The styled button
     */
    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, button.getPreferredSize().height));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        return button;
    }
    
    /**
     * Loads the initial dashboard content
     */
    private void loadDashboardContent() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create dashboard components
        JPanel dashboardPanel = new JPanel();
        dashboardPanel.setLayout(new BoxLayout(dashboardPanel, BoxLayout.Y_AXIS));
        
        // Add welcome section
        JPanel welcomePanel = new JPanel(new BorderLayout());
        JLabel dashboardTitle = new JLabel("Dashboard");
        dashboardTitle.setFont(new Font("Arial", Font.BOLD, 20));
        welcomePanel.add(dashboardTitle, BorderLayout.NORTH);
        
        // Add quick action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton quickPostButton = new JButton("Post New Job");
        quickPostButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openJobPostingView();
            }
        });
        
        JButton quickViewAppsButton = new JButton("View Applications");
        quickViewAppsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showApplications();
            }
        });
        
        actionPanel.add(quickPostButton);
        actionPanel.add(quickViewAppsButton);
        welcomePanel.add(actionPanel, BorderLayout.CENTER);
        
        // Add stats section
        JPanel statsPanel = createStatsPanel();
        
        // Add recent jobs section
        JPanel recentJobsPanel = createRecentJobsPanel();
        
        // Add recent applications section
        JPanel recentAppsPanel = createRecentApplicationsPanel();
        
        // Add content to dashboard
        dashboardPanel.add(welcomePanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(statsPanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(recentJobsPanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(recentAppsPanel);
        
        // Add dashboard to content panel with scroll pane
        JScrollPane scrollPane = new JScrollPane(dashboardPanel);
        scrollPane.setBorder(null);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Creates the statistics panel for the dashboard
     * 
     * @return The statistics panel
     */
    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new BorderLayout());
        statsPanel.setBorder(BorderFactory.createTitledBorder("Statistics"));
        
        try {
            // Get application stats
            int[] stats = applicationController.getApplicationStatistics(jobProvider.getId());
            
            // Create a panel for stats display
            JPanel statsContent = new JPanel(new GridLayout(1, 5, 10, 0));
            
            // Add stat cards
            statsContent.add(createStatCard("Total Applications", String.valueOf(stats[0]), new Color(51, 102, 153)));
            statsContent.add(createStatCard("Pending", String.valueOf(stats[1]), new Color(255, 193, 7)));
            statsContent.add(createStatCard("Reviewing", String.valueOf(stats[2]), new Color(23, 162, 184)));
            statsContent.add(createStatCard("Shortlisted", String.valueOf(stats[3]), new Color(40, 167, 69)));
            statsContent.add(createStatCard("Hired", String.valueOf(stats[4]), new Color(0, 123, 255)));
            
            statsPanel.add(statsContent, BorderLayout.CENTER);
            
        } catch (Exception e) {
            statsPanel.add(new JLabel("Error loading statistics: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return statsPanel;
    }
    
    /**
     * Creates a statistic card for the dashboard
     * 
     * @param title The stat title
     * @param value The stat value
     * @param color The background color
     * @return The stat card panel
     */
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(color);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(titleLabel, BorderLayout.SOUTH);
        
        return card;
    }
    
    /**
     * Creates the recent jobs panel for the dashboard
     * 
     * @return The recent jobs panel
     */
    private JPanel createRecentJobsPanel() {
        JPanel recentJobsPanel = new JPanel(new BorderLayout());
        recentJobsPanel.setBorder(BorderFactory.createTitledBorder("Recent Job Postings"));
        
        try {
            // Get recent jobs for this provider
            List<Job> recentJobs = jobController.getJobsByProvider(jobProvider.getId());
            
            if (recentJobs.isEmpty()) {
                recentJobsPanel.add(new JLabel("You haven't posted any jobs yet."), BorderLayout.CENTER);
            } else {
                // Create a table model
                String[] columnNames = {"Title", "Type", "Location", "Salary", "Status", "Created Date"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false; // Make table non-editable
                    }
                };
                
                // Add jobs to table
                int count = 0;
                for (Job job : recentJobs) {
                    model.addRow(new Object[]{
                        job.getTitle(),
                        job.getType(),
                        job.getLocation(),
                        "$" + salaryFormatter.format(job.getSalary()),
                        job.isActive() ? "Active" : "Inactive",
                        job.getCreatedAt().format(dateFormatter)
                    });
                    
                    count++;
                    if (count >= 5) break; // Limit to 5 most recent jobs
                }
                
                // Create table
                JTable jobsTable = new JTable(model);
                jobsTable.setRowHeight(25);
                jobsTable.getTableHeader().setReorderingAllowed(false);
                
                // Add sorting capability
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                jobsTable.setRowSorter(sorter);
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(jobsTable);
                tableScroll.setPreferredSize(new Dimension(600, 150));
                
                recentJobsPanel.add(tableScroll, BorderLayout.CENTER);
                
                // Add view all button
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton viewAllButton = new JButton("View All Jobs");
                viewAllButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        showMyJobs();
                    }
                });
                buttonPanel.add(viewAllButton);
                
                recentJobsPanel.add(buttonPanel, BorderLayout.SOUTH);
            }
            
        } catch (Exception e) {
            recentJobsPanel.add(new JLabel("Error loading jobs: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return recentJobsPanel;
    }
    
    /**
     * Creates the recent applications panel for the dashboard
     * 
     * @return The recent applications panel
     */
    private JPanel createRecentApplicationsPanel() {
        JPanel recentAppsPanel = new JPanel(new BorderLayout());
        recentAppsPanel.setBorder(BorderFactory.createTitledBorder("Recent Applications"));
        
        try {
            // Get jobs for this provider
            List<Job> jobs = jobController.getJobsByProvider(jobProvider.getId());
            
            if (jobs.isEmpty()) {
                recentAppsPanel.add(new JLabel("You haven't posted any jobs to receive applications."), BorderLayout.CENTER);
                return recentAppsPanel;
            }
            
            // Create a table model
            String[] columnNames = {"Applicant", "Job Title", "Status", "Applied Date"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Make table non-editable
                }
            };
            
            // Add applications for each job
            int totalApps = 0;
            for (Job job : jobs) {
                List<Application> applications = applicationController.getApplicationsByJob(job.getId());
                
                for (Application app : applications) {
                    // Get job seeker name
                    String seekerName = userController.getJobSeekerById(app.getSeekerId()).getFullName();
                    
                    model.addRow(new Object[]{
                        seekerName,
                        job.getTitle(),
                        app.getStatus(),
                        app.getAppliedAt().format(dateFormatter)
                    });
                    
                    totalApps++;
                    if (totalApps >= 5) break; // Limit to 5 most recent applications
                }
                
                if (totalApps >= 5) break;
            }
            
            if (totalApps == 0) {
                recentAppsPanel.add(new JLabel("You haven't received any applications yet."), BorderLayout.CENTER);
            } else {
                // Create table
                JTable appsTable = new JTable(model);
                appsTable.setRowHeight(25);
                appsTable.getTableHeader().setReorderingAllowed(false);
                
                // Add sorting capability
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                appsTable.setRowSorter(sorter);
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(appsTable);
                tableScroll.setPreferredSize(new Dimension(600, 150));
                
                recentAppsPanel.add(tableScroll, BorderLayout.CENTER);
                
                // Add view all button
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton viewAllButton = new JButton("View All Applications");
                viewAllButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        showApplications();
                    }
                });
                buttonPanel.add(viewAllButton);
                
                recentAppsPanel.add(buttonPanel, BorderLayout.SOUTH);
            }
            
        } catch (Exception e) {
            recentAppsPanel.add(new JLabel("Error loading applications: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return recentAppsPanel;
    }
    
    /**
     * Shows all job postings for this provider
     */
    private void showMyJobs() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create jobs panel
        JPanel jobsPanel = new JPanel(new BorderLayout(0, 10));
        
        // Create header panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        
        JLabel headerLabel = new JLabel("My Job Postings");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        
        JButton addButton = new JButton("Post New Job");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openJobPostingView();
            }
        });
        
        headerPanel.add(headerLabel, BorderLayout.WEST);
        headerPanel.add(addButton, BorderLayout.EAST);
        
        jobsPanel.add(headerPanel, BorderLayout.NORTH);
        
        try {
            // Get jobs
            List<Job> jobs = jobController.getJobsByProvider(jobProvider.getId());
            
            if (jobs.isEmpty()) {
                JPanel emptyPanel = new JPanel(new BorderLayout());
                JLabel emptyLabel = new JLabel("You haven't posted any jobs yet.");
                emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
                emptyPanel.add(emptyLabel, BorderLayout.CENTER);
                
                JButton firstJobButton = new JButton("Post Your First Job");
                firstJobButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        openJobPostingView();
                    }
                });
                
                JPanel buttonPanel = new JPanel();
                buttonPanel.add(firstJobButton);
                emptyPanel.add(buttonPanel, BorderLayout.SOUTH);
                
                jobsPanel.add(emptyPanel, BorderLayout.CENTER);
            } else {
                // Create table model
                String[] columnNames = {"ID", "Title", "Type", "Location", "Salary", "Deadline", "Status", "Actions"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return column == 7; // Only allow editing the actions column
                    }
                    
                    @Override
                    public Class<?> getColumnClass(int columnIndex) {
                        if (columnIndex == 7) {
                            return Object.class;
                        }
                        return String.class;
                    }
                };
                
                // Add jobs to table
                for (Job job : jobs) {
                    model.addRow(new Object[]{
                        job.getId(),
                        job.getTitle(),
                        job.getType(),
                        job.getLocation(),
                        "$" + salaryFormatter.format(job.getSalary()),
                        job.getDeadlineDate() != null ? job.getDeadlineDate().format(dateFormatter) : "None",
                        job.isActive() ? "Active" : "Inactive",
                        "Actions"
                    });
                }
                
                // Create table
                JTable jobsTable = new JTable(model);
                jobsTable.setRowHeight(30);
                jobsTable.getTableHeader().setReorderingAllowed(false);
                
                // Hide ID column
                jobsTable.getColumnModel().getColumn(0).setMinWidth(0);
                jobsTable.getColumnModel().getColumn(0).setMaxWidth(0);
                jobsTable.getColumnModel().getColumn(0).setWidth(0);
                
                // Add button renderer and editor for actions column
                jobsTable.getColumnModel().getColumn(7).setCellRenderer(new ButtonRenderer());
                jobsTable.getColumnModel().getColumn(7).setCellEditor(new ButtonEditor(new JTextField(), this, jobs));
                
                // Add sorting capability
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                jobsTable.setRowSorter(sorter);
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(jobsTable);
                
                jobsPanel.add(tableScroll, BorderLayout.CENTER);
            }
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading jobs: " + e.getMessage());
            errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
            jobsPanel.add(errorLabel, BorderLayout.CENTER);
        }
        
        // Add to content panel
        contentPanel.add(jobsPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Renderer for buttons in a table cell
     */
    private class ButtonRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        private JButton editButton;
        private JButton viewAppsButton;
        private JButton deleteButton;
        
        public ButtonRenderer() {
            setLayout(new FlowLayout(FlowLayout.CENTER, 2, 0));
            editButton = new JButton("Edit");
            editButton.setPreferredSize(new Dimension(60, 25));
            viewAppsButton = new JButton("Apps");
            viewAppsButton.setPreferredSize(new Dimension(60, 25));
            deleteButton = new JButton("Delete");
            deleteButton.setPreferredSize(new Dimension(70, 25));
            
            add(editButton);
            add(viewAppsButton);
            add(deleteButton);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }
    
    /**
     * Editor for buttons in a table cell
     */
    private class ButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton editButton;
        private JButton viewAppsButton;
        private JButton deleteButton;
        private int selectedRow;
        private JobProviderDashboard dashboard;
        private List<Job> jobs;
        
        public ButtonEditor(JTextField textField, JobProviderDashboard dashboard, List<Job> jobs) {
            super(textField);
            this.dashboard = dashboard;
            this.jobs = jobs;
            
            panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 0));
            
            editButton = new JButton("Edit");
            editButton.setPreferredSize(new Dimension(60, 25));
            viewAppsButton = new JButton("Apps");
            viewAppsButton.setPreferredSize(new Dimension(60, 25));
            deleteButton = new JButton("Delete");
            deleteButton.setPreferredSize(new Dimension(70, 25));
            
            panel.add(editButton);
            panel.add(viewAppsButton);
            panel.add(deleteButton);
            
            editButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    
                    // Get the selected job
                    Job selectedJob = jobs.get(selectedRow);
                    
                    // Open job posting view for editing
                    JobPostingView postingView = new JobPostingView(dashboard, selectedJob);
                    dashboard.setContentPanel(postingView.getContentPanel());
                }
            });
            
            viewAppsButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    
                    // Get the selected job
                    Job selectedJob = jobs.get(selectedRow);
                    
                    // Show applications for this job
                    ApplicationView applicationView = new ApplicationView(dashboard, selectedJob);
                    dashboard.setContentPanel(applicationView.getContentPanel());
                }
            });
            
            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    
                    // Get the selected job
                    Job selectedJob = jobs.get(selectedRow);
                    
                    // Confirm deletion
                    int confirm = JOptionPane.showConfirmDialog(
                        dashboard,
                        "Are you sure you want to delete the job: " + selectedJob.getTitle() + "?",
                        "Confirm Deletion",
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        // Delete job
                        boolean result = jobController.deleteJob(selectedJob.getId(), jobProvider.getId());
                        
                        if (result) {
                            JOptionPane.showMessageDialog(
                                dashboard,
                                "Job deleted successfully.",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE);
                            
                            // Refresh jobs list
                            dashboard.showMyJobs();
                        } else {
                            JOptionPane.showMessageDialog(
                                dashboard,
                                "Failed to delete job. Please try again.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            });
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.selectedRow = table.convertRowIndexToModel(row);
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "Actions";
        }
    }
    
    /**
     * Opens the job posting view for a new job
     */
    private void openJobPostingView() {
        JobPostingView jobPostingView = new JobPostingView(this, null);
        setContentPanel(jobPostingView.getContentPanel());
    }
    
    /**
     * Shows all applications for this provider's jobs
     */
    private void showApplications() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create applications panel
        JPanel applicationsPanel = new JPanel(new BorderLayout(0, 10));
        
        // Create header
        JLabel headerLabel = new JLabel("All Applications");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        applicationsPanel.add(headerLabel, BorderLayout.NORTH);
        
        // Get jobs for this provider
        List<Job> jobs = jobController.getJobsByProvider(jobProvider.getId());
        
        if (jobs.isEmpty()) {
            JLabel emptyLabel = new JLabel("You haven't posted any jobs to receive applications.");
            emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
            applicationsPanel.add(emptyLabel, BorderLayout.CENTER);
        } else {
            // Create tabbed pane for jobs
            JTabbedPane tabbedPane = new JTabbedPane();
            
            // Add a tab for all applications
            JPanel allAppsPanel = createApplicationsTabPanel(null);
            tabbedPane.addTab("All Jobs", allAppsPanel);
            
            // Add a tab for each job
            for (Job job : jobs) {
                JPanel jobAppsPanel = createApplicationsTabPanel(job);
                tabbedPane.addTab(job.getTitle(), jobAppsPanel);
            }
            
            applicationsPanel.add(tabbedPane, BorderLayout.CENTER);
        }
        
        // Add to content panel
        contentPanel.add(applicationsPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Creates a panel for an applications tab
     * 
     * @param job The job to show applications for, or null for all jobs
     * @return The panel for the tab
     */
    private JPanel createApplicationsTabPanel(Job job) {
        JPanel panel = new JPanel(new BorderLayout());
        
        try {
            List<Application> applications;
            List<Object[]> applicationsWithDetails = null;
            
            if (job != null) {
                // Get applications for this job
                applications = applicationController.getApplicationsByJob(job.getId());
            } else {
                // Get jobs for this provider
                List<Job> jobs = jobController.getJobsByProvider(jobProvider.getId());
                
                if (jobs.isEmpty()) {
                    JLabel emptyLabel = new JLabel("You haven't posted any jobs to receive applications.");
                    emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
                    panel.add(emptyLabel, BorderLayout.CENTER);
                    return panel;
                }
                
                // Collect all applications
                applications = new java.util.ArrayList<>();
                for (Job j : jobs) {
                    applications.addAll(applicationController.getApplicationsByJob(j.getId()));
                }
            }
            
            if (applications.isEmpty()) {
                JLabel emptyLabel = new JLabel("No applications received yet.");
                emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
                panel.add(emptyLabel, BorderLayout.CENTER);
            } else {
                // Create table model
                String[] columnNames;
                DefaultTableModel model;
                
                if (job != null) {
                    // For specific job
                    columnNames = new String[]{"ID", "Applicant", "Status", "Applied Date", "Actions"};
                    model = new DefaultTableModel(columnNames, 0) {
                        @Override
                        public boolean isCellEditable(int row, int column) {
                            return column == 4; // Only allow editing the actions column
                        }
                    };
                    
                    // Add applications to table
                    for (Application app : applications) {
                        // Get job seeker name
                        String seekerName = userController.getJobSeekerById(app.getSeekerId()).getFullName();
                        
                        model.addRow(new Object[]{
                            app.getId(),
                            seekerName,
                            app.getStatus(),
                            app.getAppliedAt().format(dateFormatter),
                            "Actions"
                        });
                    }
                } else {
                    // For all jobs
                    columnNames = new String[]{"ID", "Applicant", "Job Title", "Status", "Applied Date", "Actions"};
                    model = new DefaultTableModel(columnNames, 0) {
                        @Override
                        public boolean isCellEditable(int row, int column) {
                            return column == 5; // Only allow editing the actions column
                        }
                    };
                    
                    // Add applications to table
                    for (Application app : applications) {
                        // Get job seeker name
                        String seekerName = userController.getJobSeekerById(app.getSeekerId()).getFullName();
                        
                        // Get job title
                        String jobTitle = jobController.getJobById(app.getJobId()).getTitle();
                        
                        model.addRow(new Object[]{
                            app.getId(),
                            seekerName,
                            jobTitle,
                            app.getStatus(),
                            app.getAppliedAt().format(dateFormatter),
                            "Actions"
                        });
                    }
                }
                
                // Create table
                JTable appsTable = new JTable(model);
                appsTable.setRowHeight(30);
                appsTable.getTableHeader().setReorderingAllowed(false);
                
                // Hide ID column
                appsTable.getColumnModel().getColumn(0).setMinWidth(0);
                appsTable.getColumnModel().getColumn(0).setMaxWidth(0);
                appsTable.getColumnModel().getColumn(0).setWidth(0);
                
                // Add button renderer and editor for actions column
                int actionsColumn = job != null ? 4 : 5;
                appsTable.getColumnModel().getColumn(actionsColumn).setCellRenderer(new ApplicationButtonRenderer());
                appsTable.getColumnModel().getColumn(actionsColumn).setCellEditor(
                    new ApplicationButtonEditor(new JTextField(), this, applications));
                
                // Add sorting capability
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                appsTable.setRowSorter(sorter);
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(appsTable);
                
                panel.add(tableScroll, BorderLayout.CENTER);
            }
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading applications: " + e.getMessage());
            errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(errorLabel, BorderLayout.CENTER);
        }
        
        return panel;
    }
    
    /**
     * Renderer for application buttons in a table cell
     */
    private class ApplicationButtonRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        private JButton viewButton;
        private JButton statusButton;
        
        public ApplicationButtonRenderer() {
            setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
            viewButton = new JButton("View");
            viewButton.setPreferredSize(new Dimension(65, 25));
            statusButton = new JButton("Status");
            statusButton.setPreferredSize(new Dimension(75, 25));
            
            add(viewButton);
            add(statusButton);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }
    
    /**
     * Editor for application buttons in a table cell
     */
    private class ApplicationButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton viewButton;
        private JButton statusButton;
        private int selectedRow;
        private JobProviderDashboard dashboard;
        private List<Application> applications;
        
        public ApplicationButtonEditor(JTextField textField, JobProviderDashboard dashboard, List<Application> applications) {
            super(textField);
            this.dashboard = dashboard;
            this.applications = applications;
            
            panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
            
            viewButton = new JButton("View");
            viewButton.setPreferredSize(new Dimension(65, 25));
            statusButton = new JButton("Status");
            statusButton.setPreferredSize(new Dimension(75, 25));
            
            panel.add(viewButton);
            panel.add(statusButton);
            
            viewButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    viewApplication(applications.get(selectedRow));
                }
            });
            
            statusButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    changeApplicationStatus(applications.get(selectedRow));
                }
            });
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.selectedRow = table.convertRowIndexToModel(row);
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "Actions";
        }
    }
    
    /**
     * Shows detailed view of an application
     * 
     * @param application The application to view
     */
    private void viewApplication(Application application) {
        // Create dialog
        JDialog detailsDialog = new JDialog(this, "Application Details", true);
        detailsDialog.setSize(600, 550);
        detailsDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Application info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        
        try {
            // Get job seeker
            Job job = jobController.getJobById(application.getJobId());
            JobSeeker seeker = userController.getJobSeekerById(application.getSeekerId());
            
            // Job title
            JLabel titleLabel = new JLabel(job.getTitle());
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            // Applicant name
            JLabel applicantLabel = new JLabel("Applicant: " + seeker.getFullName());
            applicantLabel.setFont(new Font("Arial", Font.BOLD, 16));
            applicantLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            // Status with colored background
            JPanel statusPanel = new JPanel();
            statusPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            JLabel statusLabel = new JLabel("Status: " + application.getStatus());
            statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
            statusPanel.add(statusLabel);
            
            // Applied date
            JLabel appliedLabel = new JLabel("Applied on: " + 
                application.getAppliedAt().format(DateTimeFormatter.ofPattern("dd MMMM yyyy")));
            appliedLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            // Add components to info panel
            infoPanel.add(titleLabel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            infoPanel.add(applicantLabel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            infoPanel.add(statusPanel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            infoPanel.add(appliedLabel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
            
            // Applicant info tabs
            JTabbedPane tabbedPane = new JTabbedPane();
            
            // Cover letter tab
            JPanel coverLetterPanel = new JPanel(new BorderLayout());
            JTextArea coverLetterArea = new JTextArea(application.getCoverLetter());
            coverLetterArea.setLineWrap(true);
            coverLetterArea.setWrapStyleWord(true);
            coverLetterArea.setEditable(false);
            JScrollPane coverLetterScroll = new JScrollPane(coverLetterArea);
            coverLetterPanel.add(coverLetterScroll, BorderLayout.CENTER);
            tabbedPane.addTab("Cover Letter", coverLetterPanel);
            
            // Resume tab
            JPanel resumePanel = new JPanel(new BorderLayout());
            JTextArea resumeArea = new JTextArea(seeker.getResume());
            resumeArea.setLineWrap(true);
            resumeArea.setWrapStyleWord(true);
            resumeArea.setEditable(false);
            JScrollPane resumeScroll = new JScrollPane(resumeArea);
            resumePanel.add(resumeScroll, BorderLayout.CENTER);
            tabbedPane.addTab("Resume", resumePanel);
            
            // Skills tab
            JPanel skillsPanel = new JPanel(new BorderLayout());
            JTextArea skillsArea = new JTextArea(seeker.getSkills());
            skillsArea.setLineWrap(true);
            skillsArea.setWrapStyleWord(true);
            skillsArea.setEditable(false);
            JScrollPane skillsScroll = new JScrollPane(skillsArea);
            skillsPanel.add(skillsScroll, BorderLayout.CENTER);
            tabbedPane.addTab("Skills", skillsPanel);
            
            // Notes tab (editable)
            JPanel notesPanel = new JPanel(new BorderLayout());
            JTextArea notesArea = new JTextArea(application.getNotes());
            notesArea.setLineWrap(true);
            notesArea.setWrapStyleWord(true);
            JScrollPane notesScroll = new JScrollPane(notesArea);
            
            JButton saveNotesButton = new JButton("Save Notes");
            saveNotesButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    application.setNotes(notesArea.getText());
                    applicationController.updateApplicationStatus(application);
                    JOptionPane.showMessageDialog(
                        detailsDialog,
                        "Notes saved successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                }
            });
            
            JPanel notesButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            notesButtonPanel.add(saveNotesButton);
            
            notesPanel.add(notesScroll, BorderLayout.CENTER);
            notesPanel.add(notesButtonPanel, BorderLayout.SOUTH);
            tabbedPane.addTab("Notes", notesPanel);
            
            // Add tabbed pane to info panel
            infoPanel.add(tabbedPane);
            
            // Add info panel to main panel
            panel.add(infoPanel, BorderLayout.CENTER);
            
            // Button panel
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            
            // Change status button
            JButton changeStatusButton = new JButton("Change Status");
            changeStatusButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    detailsDialog.dispose();
                    changeApplicationStatus(application);
                }
            });
            buttonPanel.add(changeStatusButton);
            
            // Close button
            JButton closeButton = new JButton("Close");
            closeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    detailsDialog.dispose();
                }
            });
            buttonPanel.add(closeButton);
            
            panel.add(buttonPanel, BorderLayout.SOUTH);
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading application details: " + e.getMessage());
            panel.add(errorLabel, BorderLayout.CENTER);
        }
        
        detailsDialog.add(panel);
        detailsDialog.setVisible(true);
    }
    
    /**
     * Opens a dialog to change application status
     * 
     * @param application The application to update
     */
    private void changeApplicationStatus(Application application) {
        // Create dialog
        JDialog statusDialog = new JDialog(this, "Change Application Status", true);
        statusDialog.setSize(400, 300);
        statusDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Create panel for status selection
        JPanel selectionPanel = new JPanel();
        selectionPanel.setLayout(new BoxLayout(selectionPanel, BoxLayout.Y_AXIS));
        
        JLabel titleLabel = new JLabel("Select New Status");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        selectionPanel.add(titleLabel);
        selectionPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Status options
        String[] statuses = {
            Application.STATUS_PENDING,
            Application.STATUS_REVIEWING,
            Application.STATUS_SHORTLISTED,
            Application.STATUS_INTERVIEW,
            Application.STATUS_OFFERED,
            Application.STATUS_HIRED,
            Application.STATUS_REJECTED
        };
        
        JComboBox<String> statusCombo = new JComboBox<>(statuses);
        statusCombo.setSelectedItem(application.getStatus());
        statusCombo.setAlignmentX(Component.LEFT_ALIGNMENT);
        selectionPanel.add(statusCombo);
        selectionPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Notes field
        JLabel notesLabel = new JLabel("Notes (optional):");
        notesLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        selectionPanel.add(notesLabel);
        selectionPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        
        JTextArea notesArea = new JTextArea(5, 20);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);
        if (application.getNotes() != null) {
            notesArea.setText(application.getNotes());
        }
        
        JScrollPane notesScroll = new JScrollPane(notesArea);
        notesScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        selectionPanel.add(notesScroll);
        
        panel.add(selectionPanel, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                statusDialog.dispose();
            }
        });
        
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Update application
                application.setStatus((String) statusCombo.getSelectedItem());
                application.setNotes(notesArea.getText());
                boolean success = applicationController.updateApplicationStatus(application);
                
                if (success) {
                    JOptionPane.showMessageDialog(
                        statusDialog,
                        "Application status updated successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                    statusDialog.dispose();
                    showApplications(); // Refresh the view
                } else {
                    JOptionPane.showMessageDialog(
                        statusDialog,
                        "Failed to update application status. Please try again.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        statusDialog.add(panel);
        statusDialog.setVisible(true);
    }
    
    /**
     * Opens the profile view
     */
    private void openProfileView() {
        // Refresh job provider data
        jobProvider = userController.getJobProviderById(jobProvider.getId());
        
        // Create profile view
        ProfileView profileView = new ProfileView(this, jobProvider);
        setContentPanel(profileView.getContentPanel());
    }
    
    /**
     * Sets the content of the content panel
     * 
     * @param newContent The new content panel
     */
    public void setContentPanel(JPanel newContent) {
        contentPanel.removeAll();
        contentPanel.add(newContent, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Refreshes the job provider data
     * 
     * @param updatedProvider The updated job provider data
     */
    public void updateJobProvider(JobProvider updatedProvider) {
        this.jobProvider = updatedProvider;
        welcomeLabel.setText("Welcome, " + jobProvider.getCompanyName());
    }
    
    /**
     * Logs out the user
     */
    private void logout() {
        int result = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            dispose();
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
        }
    }
    
    /**
     * Gets the job provider
     * 
     * @return The job provider
     */
    public JobProvider getJobProvider() {
        return jobProvider;
    }
    
    /**
     * Refreshes the dashboard content
     */
    public void refreshContent() {
        loadDashboardContent();
    }
}
