package com.jobportal.view;

import com.jobportal.controller.ApplicationController;
import com.jobportal.controller.JobController;
import com.jobportal.controller.UserController;
import com.jobportal.model.Administrator;
import com.jobportal.model.Job;
import com.jobportal.model.JobProvider;
import com.jobportal.model.JobSeeker;
import com.jobportal.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Dashboard view for administrators.
 * Provides access to system oversight, user management, and job moderation.
 */
public class AdminDashboard extends JFrame {
    private Administrator administrator;
    private JobController jobController;
    private ApplicationController applicationController;
    private UserController userController;
    
    // UI Components
    private JPanel mainPanel;
    private JPanel contentPanel;
    private JLabel welcomeLabel;
    private JButton dashboardButton;
    private JButton usersButton;
    private JButton jobsButton;
    private JButton profileButton;
    private JButton logoutButton;
    
    // Formatters
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
    private DecimalFormat salaryFormatter = new DecimalFormat("#,##0.00");
    
    /**
     * Constructor initializes the dashboard with user data
     * 
     * @param administrator The logged-in administrator
     */
    public AdminDashboard(Administrator administrator) {
        this.administrator = administrator;
        this.jobController = new JobController();
        this.applicationController = new ApplicationController();
        this.userController = new UserController();
        
        initializeUI();
        loadDashboardContent();
    }
    
    /**
     * Sets up the user interface
     */
    private void initializeUI() {
        // Configure the frame
        setTitle("Job Portal - Administrator Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null); // Center on screen
        
        // Create main panel
        mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create navigation panel (sidebar)
        JPanel navPanel = createNavigationPanel();
        mainPanel.add(navPanel, BorderLayout.WEST);
        
        // Create content panel
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Add the main panel to the frame
        add(mainPanel);
        
        // Set action listeners for navigation buttons
        dashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadDashboardContent();
            }
        });
        
        usersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showUsersManagement();
            }
        });
        
        jobsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showJobsManagement();
            }
        });
        
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openProfileView();
            }
        });
        
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });
    }
    
    /**
     * Creates the header panel
     * 
     * @return The header panel
     */
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(51, 102, 153));
        headerPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        
        welcomeLabel = new JLabel("Welcome, Admin " + administrator.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        
        headerPanel.add(welcomeLabel, BorderLayout.WEST);
        
        logoutButton = new JButton("Logout");
        headerPanel.add(logoutButton, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    /**
     * Creates the navigation panel (sidebar)
     * 
     * @return The navigation panel
     */
    private JPanel createNavigationPanel() {
        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBackground(new Color(240, 240, 240));
        navPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        navPanel.setPreferredSize(new Dimension(200, getHeight()));
        
        // Create navigation buttons
        dashboardButton = createNavButton("Dashboard");
        usersButton = createNavButton("User Management");
        jobsButton = createNavButton("Job Management");
        profileButton = createNavButton("My Profile");
        
        // Add buttons to panel
        navPanel.add(dashboardButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(usersButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(jobsButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(profileButton);
        navPanel.add(Box.createVerticalGlue());
        
        return navPanel;
    }
    
    /**
     * Creates a styled navigation button
     * 
     * @param text The button text
     * @return The styled button
     */
    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, button.getPreferredSize().height));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        return button;
    }
    
    /**
     * Loads the initial dashboard content
     */
    private void loadDashboardContent() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create dashboard components
        JPanel dashboardPanel = new JPanel();
        dashboardPanel.setLayout(new BoxLayout(dashboardPanel, BoxLayout.Y_AXIS));
        
        // Add welcome section
        JPanel welcomePanel = new JPanel(new BorderLayout());
        JLabel dashboardTitle = new JLabel("Administrator Dashboard");
        dashboardTitle.setFont(new Font("Arial", Font.BOLD, 20));
        welcomePanel.add(dashboardTitle, BorderLayout.NORTH);
        
        // Add stats section
        JPanel statsPanel = createStatsPanel();
        
        // Add recent users section
        JPanel recentUsersPanel = createRecentUsersPanel();
        
        // Add recent jobs section
        JPanel recentJobsPanel = createRecentJobsPanel();
        
        // Add content to dashboard
        dashboardPanel.add(welcomePanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(statsPanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(recentUsersPanel);
        dashboardPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        dashboardPanel.add(recentJobsPanel);
        
        // Add dashboard to content panel with scroll pane
        JScrollPane scrollPane = new JScrollPane(dashboardPanel);
        scrollPane.setBorder(null);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Creates the statistics panel for the dashboard
     * 
     * @return The statistics panel
     */
    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new BorderLayout());
        statsPanel.setBorder(BorderFactory.createTitledBorder("System Statistics"));
        
        try {
            // Get stats
            List<JobSeeker> jobSeekers = userController.getAllJobSeekers();
            List<JobProvider> jobProviders = userController.getAllJobProviders();
            List<Job> recentJobs = jobController.getRecentJobs(Integer.MAX_VALUE);
            
            // Count active vs inactive jobs
            int activeJobs = 0;
            for (Job job : recentJobs) {
                if (job.isActive()) {
                    activeJobs++;
                }
            }
            
            // Create a panel for stats display
            JPanel statsContent = new JPanel(new GridLayout(1, 4, 10, 0));
            
            // Add stat cards
            statsContent.add(createStatCard("Job Seekers", String.valueOf(jobSeekers.size()), new Color(51, 102, 153)));
            statsContent.add(createStatCard("Job Providers", String.valueOf(jobProviders.size()), new Color(40, 167, 69)));
            statsContent.add(createStatCard("Total Jobs", String.valueOf(recentJobs.size()), new Color(255, 193, 7)));
            statsContent.add(createStatCard("Active Jobs", String.valueOf(activeJobs), new Color(23, 162, 184)));
            
            statsPanel.add(statsContent, BorderLayout.CENTER);
            
        } catch (Exception e) {
            statsPanel.add(new JLabel("Error loading statistics: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return statsPanel;
    }
    
    /**
     * Creates a statistic card for the dashboard
     * 
     * @param title The stat title
     * @param value The stat value
     * @param color The background color
     * @return The stat card panel
     */
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(color);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(titleLabel, BorderLayout.SOUTH);
        
        return card;
    }
    
    /**
     * Creates the recent users panel for the dashboard
     * 
     * @return The recent users panel
     */
    private JPanel createRecentUsersPanel() {
        JPanel recentUsersPanel = new JPanel(new BorderLayout());
        recentUsersPanel.setBorder(BorderFactory.createTitledBorder("Recent Users"));
        
        try {
            // Get users
            List<JobSeeker> jobSeekers = userController.getAllJobSeekers();
            List<JobProvider> jobProviders = userController.getAllJobProviders();
            
            // Create a table model
            String[] columnNames = {"Name", "Username", "Email", "User Type", "Status"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Make table non-editable
                }
            };
            
            // Add job seekers to table
            int count = 0;
            for (JobSeeker seeker : jobSeekers) {
                model.addRow(new Object[]{
                    seeker.getFullName(),
                    seeker.getUsername(),
                    seeker.getEmail(),
                    "Job Seeker",
                    seeker.isActive() ? "Active" : "Inactive"
                });
                
                count++;
                if (count >= 5) break; // Limit to 5 recent users
            }
            
            // Add job providers to table
            for (JobProvider provider : jobProviders) {
                if (count >= 5) break; // Limit to 5 recent users
                
                model.addRow(new Object[]{
                    provider.getCompanyName(),
                    provider.getUsername(),
                    provider.getEmail(),
                    "Job Provider",
                    provider.isActive() ? "Active" : "Inactive"
                });
                
                count++;
            }
            
            if (count == 0) {
                recentUsersPanel.add(new JLabel("No users in the system."), BorderLayout.CENTER);
            } else {
                // Create table
                JTable usersTable = new JTable(model);
                usersTable.setRowHeight(25);
                usersTable.getTableHeader().setReorderingAllowed(false);
                
                // Add sorting capability
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                usersTable.setRowSorter(sorter);
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(usersTable);
                tableScroll.setPreferredSize(new Dimension(600, 150));
                
                recentUsersPanel.add(tableScroll, BorderLayout.CENTER);
                
                // Add view all button
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton viewAllButton = new JButton("Manage Users");
                viewAllButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        showUsersManagement();
                    }
                });
                buttonPanel.add(viewAllButton);
                
                recentUsersPanel.add(buttonPanel, BorderLayout.SOUTH);
            }
            
        } catch (Exception e) {
            recentUsersPanel.add(new JLabel("Error loading users: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return recentUsersPanel;
    }
    
    /**
     * Creates the recent jobs panel for the dashboard
     * 
     * @return The recent jobs panel
     */
    private JPanel createRecentJobsPanel() {
        JPanel recentJobsPanel = new JPanel(new BorderLayout());
        recentJobsPanel.setBorder(BorderFactory.createTitledBorder("Recent Job Postings"));
        
        try {
            // Get jobs
            List<Job> recentJobs = jobController.getRecentJobs(5);
            
            if (recentJobs.isEmpty()) {
                recentJobsPanel.add(new JLabel("No jobs in the system."), BorderLayout.CENTER);
            } else {
                // Create a table model
                String[] columnNames = {"Title", "Company", "Type", "Location", "Status", "Created Date"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false; // Make table non-editable
                    }
                };
                
                // Add jobs to table
                for (Job job : recentJobs) {
                    // Get company name
                    String companyName = "Unknown";
                    try {
                        JobProvider provider = userController.getJobProviderById(job.getProviderId());
                        if (provider != null) {
                            companyName = provider.getCompanyName();
                        }
                    } catch (Exception e) {
                        // Use default if error
                    }
                    
                    model.addRow(new Object[]{
                        job.getTitle(),
                        companyName,
                        job.getType(),
                        job.getLocation(),
                        job.isActive() ? "Active" : "Inactive",
                        job.getCreatedAt().format(dateFormatter)
                    });
                }
                
                // Create table
                JTable jobsTable = new JTable(model);
                jobsTable.setRowHeight(25);
                jobsTable.getTableHeader().setReorderingAllowed(false);
                
                // Add sorting capability
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                jobsTable.setRowSorter(sorter);
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(jobsTable);
                tableScroll.setPreferredSize(new Dimension(600, 150));
                
                recentJobsPanel.add(tableScroll, BorderLayout.CENTER);
                
                // Add view all button
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton viewAllButton = new JButton("Manage Jobs");
                viewAllButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        showJobsManagement();
                    }
                });
                buttonPanel.add(viewAllButton);
                
                recentJobsPanel.add(buttonPanel, BorderLayout.SOUTH);
            }
            
        } catch (Exception e) {
            recentJobsPanel.add(new JLabel("Error loading jobs: " + e.getMessage()), BorderLayout.CENTER);
        }
        
        return recentJobsPanel;
    }
    
    /**
     * Shows the user management interface
     */
    private void showUsersManagement() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create tabbed pane for different user types
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Add tab for job seekers
        JPanel seekersPanel = createJobSeekersPanel();
        tabbedPane.addTab("Job Seekers", seekersPanel);
        
        // Add tab for job providers
        JPanel providersPanel = createJobProvidersPanel();
        tabbedPane.addTab("Job Providers", providersPanel);
        
        // Add the tabbed pane to the content panel
        contentPanel.add(tabbedPane, BorderLayout.CENTER);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Creates the job seekers panel for user management
     * 
     * @return The job seekers panel
     */
    private JPanel createJobSeekersPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        try {
            // Get job seekers
            List<JobSeeker> jobSeekers = userController.getAllJobSeekers();
            
            if (jobSeekers.isEmpty()) {
                JLabel emptyLabel = new JLabel("No job seekers in the system.");
                emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
                panel.add(emptyLabel, BorderLayout.CENTER);
            } else {
                // Create a table model
                String[] columnNames = {"ID", "Name", "Username", "Email", "Phone", "Status", "Actions"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return column == 6; // Only allow editing the actions column
                    }
                };
                
                // Add job seekers to table
                for (JobSeeker seeker : jobSeekers) {
                    model.addRow(new Object[]{
                        seeker.getId(),
                        seeker.getFullName(),
                        seeker.getUsername(),
                        seeker.getEmail(),
                        seeker.getPhone(),
                        seeker.isActive() ? "Active" : "Inactive",
                        "Actions"
                    });
                }
                
                // Create table
                JTable seekersTable = new JTable(model);
                seekersTable.setRowHeight(30);
                seekersTable.getTableHeader().setReorderingAllowed(false);
                
                // Hide ID column
                seekersTable.getColumnModel().getColumn(0).setMinWidth(0);
                seekersTable.getColumnModel().getColumn(0).setMaxWidth(0);
                seekersTable.getColumnModel().getColumn(0).setWidth(0);
                
                // Add button renderer and editor for actions column
                seekersTable.getColumnModel().getColumn(6).setCellRenderer(new UserButtonRenderer());
                seekersTable.getColumnModel().getColumn(6).setCellEditor(
                    new UserButtonEditor(new JTextField(), this, jobSeekers, User.JOB_SEEKER));
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(seekersTable);
                
                panel.add(tableScroll, BorderLayout.CENTER);
            }
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading job seekers: " + e.getMessage());
            errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(errorLabel, BorderLayout.CENTER);
        }
        
        return panel;
    }
    
    /**
     * Creates the job providers panel for user management
     * 
     * @return The job providers panel
     */
    private JPanel createJobProvidersPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        try {
            // Get job providers
            List<JobProvider> jobProviders = userController.getAllJobProviders();
            
            if (jobProviders.isEmpty()) {
                JLabel emptyLabel = new JLabel("No job providers in the system.");
                emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
                panel.add(emptyLabel, BorderLayout.CENTER);
            } else {
                // Create a table model
                String[] columnNames = {"ID", "Company", "Contact Person", "Email", "Industry", "Status", "Actions"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return column == 6; // Only allow editing the actions column
                    }
                };
                
                // Add job providers to table
                for (JobProvider provider : jobProviders) {
                    model.addRow(new Object[]{
                        provider.getId(),
                        provider.getCompanyName(),
                        provider.getFullName(),
                        provider.getEmail(),
                        provider.getIndustry(),
                        provider.isActive() ? "Active" : "Inactive",
                        "Actions"
                    });
                }
                
                // Create table
                JTable providersTable = new JTable(model);
                providersTable.setRowHeight(30);
                providersTable.getTableHeader().setReorderingAllowed(false);
                
                // Hide ID column
                providersTable.getColumnModel().getColumn(0).setMinWidth(0);
                providersTable.getColumnModel().getColumn(0).setMaxWidth(0);
                providersTable.getColumnModel().getColumn(0).setWidth(0);
                
                // Add button renderer and editor for actions column
                providersTable.getColumnModel().getColumn(6).setCellRenderer(new UserButtonRenderer());
                providersTable.getColumnModel().getColumn(6).setCellEditor(
                    new UserButtonEditor(new JTextField(), this, jobProviders, User.JOB_PROVIDER));
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(providersTable);
                
                panel.add(tableScroll, BorderLayout.CENTER);
            }
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading job providers: " + e.getMessage());
            errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(errorLabel, BorderLayout.CENTER);
        }
        
        return panel;
    }
    
    /**
     * Renderer for user management buttons in a table cell
     */
    private class UserButtonRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        private JButton viewButton;
        private JButton toggleButton;
        private JButton deleteButton;
        
        public UserButtonRenderer() {
            setLayout(new FlowLayout(FlowLayout.CENTER, 2, 0));
            viewButton = new JButton("View");
            viewButton.setPreferredSize(new Dimension(60, 25));
            toggleButton = new JButton("Toggle");
            toggleButton.setPreferredSize(new Dimension(70, 25));
            deleteButton = new JButton("Delete");
            deleteButton.setPreferredSize(new Dimension(70, 25));
            
            add(viewButton);
            add(toggleButton);
            add(deleteButton);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }
    
    /**
     * Editor for user management buttons in a table cell
     */
    private class UserButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton viewButton;
        private JButton toggleButton;
        private JButton deleteButton;
        private int selectedRow;
        private AdminDashboard dashboard;
        private List<?> users;
        private int userType;
        
        public UserButtonEditor(JTextField textField, AdminDashboard dashboard, List<?> users, int userType) {
            super(textField);
            this.dashboard = dashboard;
            this.users = users;
            this.userType = userType;
            
            panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 0));
            
            viewButton = new JButton("View");
            viewButton.setPreferredSize(new Dimension(60, 25));
            toggleButton = new JButton("Toggle");
            toggleButton.setPreferredSize(new Dimension(70, 25));
            deleteButton = new JButton("Delete");
            deleteButton.setPreferredSize(new Dimension(70, 25));
            
            panel.add(viewButton);
            panel.add(toggleButton);
            panel.add(deleteButton);
            
            viewButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    User selectedUser = (User) users.get(selectedRow);
                    viewUserDetails(selectedUser);
                }
            });
            
            toggleButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    User selectedUser = (User) users.get(selectedRow);
                    toggleUserStatus(selectedUser);
                }
            });
            
            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    User selectedUser = (User) users.get(selectedRow);
                    deleteUser(selectedUser);
                }
            });
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.selectedRow = table.convertRowIndexToModel(row);
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "Actions";
        }
    }
    
    /**
     * Shows detailed information about a user
     * 
     * @param user The user to display
     */
    private void viewUserDetails(User user) {
        // Create dialog
        JDialog detailsDialog = new JDialog(this, "User Details", true);
        detailsDialog.setSize(500, 500);
        detailsDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // User info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        
        // Add common user info
        addUserCommonInfo(infoPanel, user);
        
        // Add user type specific info
        if (user.getUserType() == User.JOB_SEEKER) {
            addJobSeekerInfo(infoPanel, (JobSeeker) user);
        } else if (user.getUserType() == User.JOB_PROVIDER) {
            addJobProviderInfo(infoPanel, (JobProvider) user);
        }
        
        // Add to scroll pane
        JScrollPane scrollPane = new JScrollPane(infoPanel);
        scrollPane.setBorder(null);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        // Toggle active status button
        JButton toggleButton = new JButton(user.isActive() ? "Deactivate User" : "Activate User");
        toggleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleUserStatus(user);
                detailsDialog.dispose();
            }
        });
        buttonPanel.add(toggleButton);
        
        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                detailsDialog.dispose();
            }
        });
        buttonPanel.add(closeButton);
        
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        detailsDialog.add(panel);
        detailsDialog.setVisible(true);
    }
    
    /**
     * Adds common user information to the info panel
     * 
     * @param infoPanel The panel to add information to
     * @param user The user to display information for
     */
    private void addUserCommonInfo(JPanel infoPanel, User user) {
        // User title
        JLabel titleLabel = new JLabel("User Information");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoPanel.add(titleLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Create grid for user info
        JPanel gridPanel = new JPanel(new GridLayout(0, 2, 10, 5));
        gridPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Add fields
        addField(gridPanel, "User ID:", String.valueOf(user.getId()));
        addField(gridPanel, "Username:", user.getUsername());
        addField(gridPanel, "Full Name:", user.getFullName());
        addField(gridPanel, "Email:", user.getEmail());
        addField(gridPanel, "Phone:", user.getPhone());
        addField(gridPanel, "Account Status:", user.isActive() ? "Active" : "Inactive");
        
        // Format dates
        String createdAt = user.getCreatedAt() != null ? 
                          user.getCreatedAt().format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm")) : 
                          "N/A";
        
        String lastLogin = user.getLastLogin() != null ? 
                          user.getLastLogin().format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm")) : 
                          "Never";
        
        addField(gridPanel, "Created On:", createdAt);
        addField(gridPanel, "Last Login:", lastLogin);
        
        infoPanel.add(gridPanel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
    }
    
    /**
     * Adds job seeker specific information to the info panel
     * 
     * @param infoPanel The panel to add information to
     * @param jobSeeker The job seeker to display information for
     */
    private void addJobSeekerInfo(JPanel infoPanel, JobSeeker jobSeeker) {
        // Job seeker title
        JLabel titleLabel = new JLabel("Job Seeker Details");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoPanel.add(titleLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Create tabbed pane for different sections
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Resume tab
        JPanel resumePanel = new JPanel(new BorderLayout());
        JTextArea resumeArea = new JTextArea(jobSeeker.getResume() != null ? jobSeeker.getResume() : "No resume provided.");
        resumeArea.setLineWrap(true);
        resumeArea.setWrapStyleWord(true);
        resumeArea.setEditable(false);
        JScrollPane resumeScroll = new JScrollPane(resumeArea);
        resumePanel.add(resumeScroll, BorderLayout.CENTER);
        tabbedPane.addTab("Resume", resumePanel);
        
        // Skills tab
        JPanel skillsPanel = new JPanel(new BorderLayout());
        JTextArea skillsArea = new JTextArea(jobSeeker.getSkills() != null ? jobSeeker.getSkills() : "No skills provided.");
        skillsArea.setLineWrap(true);
        skillsArea.setWrapStyleWord(true);
        skillsArea.setEditable(false);
        JScrollPane skillsScroll = new JScrollPane(skillsArea);
        skillsPanel.add(skillsScroll, BorderLayout.CENTER);
        tabbedPane.addTab("Skills", skillsPanel);
        
        // Education tab
        JPanel educationPanel = new JPanel(new BorderLayout());
        JTextArea educationArea = new JTextArea(jobSeeker.getEducation() != null ? jobSeeker.getEducation() : "No education information provided.");
        educationArea.setLineWrap(true);
        educationArea.setWrapStyleWord(true);
        educationArea.setEditable(false);
        JScrollPane educationScroll = new JScrollPane(educationArea);
        educationPanel.add(educationScroll, BorderLayout.CENTER);
        tabbedPane.addTab("Education", educationPanel);
        
        // Experience tab
        JPanel experiencePanel = new JPanel(new BorderLayout());
        JTextArea experienceArea = new JTextArea(jobSeeker.getExperience() != null ? jobSeeker.getExperience() : "No experience information provided.");
        experienceArea.setLineWrap(true);
        experienceArea.setWrapStyleWord(true);
        experienceArea.setEditable(false);
        JScrollPane experienceScroll = new JScrollPane(experienceArea);
        experiencePanel.add(experienceScroll, BorderLayout.CENTER);
        tabbedPane.addTab("Experience", experiencePanel);
        
        // Preferences tab
        JPanel preferencesPanel = new JPanel(new BorderLayout());
        JTextArea preferencesArea = new JTextArea(jobSeeker.getPreferences() != null ? jobSeeker.getPreferences() : "No job preferences provided.");
        preferencesArea.setLineWrap(true);
        preferencesArea.setWrapStyleWord(true);
        preferencesArea.setEditable(false);
        JScrollPane preferencesScroll = new JScrollPane(preferencesArea);
        preferencesPanel.add(preferencesScroll, BorderLayout.CENTER);
        tabbedPane.addTab("Preferences", preferencesPanel);
        
        infoPanel.add(tabbedPane);
    }
    
    /**
     * Adds job provider specific information to the info panel
     * 
     * @param infoPanel The panel to add information to
     * @param jobProvider The job provider to display information for
     */
    private void addJobProviderInfo(JPanel infoPanel, JobProvider jobProvider) {
        // Job provider title
        JLabel titleLabel = new JLabel("Company Details");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoPanel.add(titleLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Create grid for company info
        JPanel gridPanel = new JPanel(new GridLayout(0, 2, 10, 5));
        gridPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Add fields
        addField(gridPanel, "Company Name:", jobProvider.getCompanyName());
        addField(gridPanel, "Industry:", jobProvider.getIndustry());
        addField(gridPanel, "Location:", jobProvider.getLocation());
        addField(gridPanel, "Website:", jobProvider.getWebsite() != null ? jobProvider.getWebsite() : "Not provided");
        
        infoPanel.add(gridPanel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Company description
        JLabel descLabel = new JLabel("Company Description:");
        descLabel.setFont(new Font("Arial", Font.BOLD, 14));
        descLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoPanel.add(descLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        
        JTextArea descArea = new JTextArea(jobProvider.getCompanyDescription() != null ? 
                                          jobProvider.getCompanyDescription() : 
                                          "No company description provided.");
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setEditable(false);
        JScrollPane descScroll = new JScrollPane(descArea);
        descScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        descScroll.setPreferredSize(new Dimension(400, 100));
        infoPanel.add(descScroll);
    }
    
    /**
     * Adds a field to the grid panel
     * 
     * @param panel The panel to add to
     * @param label The label text
     * @param value The value text
     */
    private void addField(JPanel panel, String label, String value) {
        panel.add(new JLabel(label, SwingConstants.RIGHT));
        panel.add(new JLabel(value != null ? value : ""));
    }
    
    /**
     * Toggles a user's active status
     * 
     * @param user The user to toggle status for
     */
    private void toggleUserStatus(User user) {
        // Toggle status
        user.setActive(!user.isActive());
        
        // Update in database
        boolean success = false;
        
        if (user.getUserType() == User.JOB_SEEKER) {
            success = userController.updateJobSeekerProfile((JobSeeker) user);
        } else if (user.getUserType() == User.JOB_PROVIDER) {
            success = userController.updateJobProviderProfile((JobProvider) user);
        }
        
        if (success) {
            JOptionPane.showMessageDialog(this,
                "User status updated successfully.",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Refresh view
            showUsersManagement();
        } else {
            JOptionPane.showMessageDialog(this,
                "Failed to update user status.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Deletes a user from the system
     * 
     * @param user The user to delete
     */
    private void deleteUser(User user) {
        // Confirm deletion
        int result = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this user? This action cannot be undone.",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            // Delete from database
            boolean success = userController.deleteUser(user.getId(), user.getUserType());
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "User deleted successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh view
                showUsersManagement();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to delete user.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * Shows the job management interface
     */
    private void showJobsManagement() {
        // Clear content panel
        contentPanel.removeAll();
        
        // Create jobs panel
        JPanel jobsPanel = new JPanel(new BorderLayout());
        
        // Create header
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel headerLabel = new JLabel("Job Management");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerPanel.add(headerLabel, BorderLayout.WEST);
        
        // Add search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search Jobs:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        headerPanel.add(searchPanel, BorderLayout.EAST);
        jobsPanel.add(headerPanel, BorderLayout.NORTH);
        
        try {
            // Get all jobs
            List<Job> jobs = jobController.getRecentJobs(Integer.MAX_VALUE);
            
            if (jobs.isEmpty()) {
                JLabel emptyLabel = new JLabel("No jobs in the system.");
                emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
                jobsPanel.add(emptyLabel, BorderLayout.CENTER);
            } else {
                // Create a table model
                String[] columnNames = {"ID", "Title", "Company", "Type", "Location", "Status", "Created", "Actions"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return column == 7; // Only allow editing the actions column
                    }
                };
                
                // Add jobs to table
                for (Job job : jobs) {
                    // Get company name
                    String companyName = "Unknown";
                    try {
                        JobProvider provider = userController.getJobProviderById(job.getProviderId());
                        if (provider != null) {
                            companyName = provider.getCompanyName();
                        }
                    } catch (Exception e) {
                        // Use default if error
                    }
                    
                    model.addRow(new Object[]{
                        job.getId(),
                        job.getTitle(),
                        companyName,
                        job.getType(),
                        job.getLocation(),
                        job.isActive() ? "Active" : "Inactive",
                        job.getCreatedAt().format(dateFormatter),
                        "Actions"
                    });
                }
                
                // Create table
                JTable jobsTable = new JTable(model);
                jobsTable.setRowHeight(30);
                jobsTable.getTableHeader().setReorderingAllowed(false);
                
                // Hide ID column
                jobsTable.getColumnModel().getColumn(0).setMinWidth(0);
                jobsTable.getColumnModel().getColumn(0).setMaxWidth(0);
                jobsTable.getColumnModel().getColumn(0).setWidth(0);
                
                // Add button renderer and editor for actions column
                jobsTable.getColumnModel().getColumn(7).setCellRenderer(new JobButtonRenderer());
                jobsTable.getColumnModel().getColumn(7).setCellEditor(
                    new JobButtonEditor(new JTextField(), this, jobs));
                
                // Add table to a scroll pane
                JScrollPane tableScroll = new JScrollPane(jobsTable);
                
                jobsPanel.add(tableScroll, BorderLayout.CENTER);
                
                // Add search functionality
                searchButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String searchText = searchField.getText().trim().toLowerCase();
                        if (searchText.isEmpty()) {
                            ((DefaultTableModel) jobsTable.getModel()).setRowCount(0);
                            for (Job job : jobs) {
                                // Get company name
                                String companyName = "Unknown";
                                try {
                                    JobProvider provider = userController.getJobProviderById(job.getProviderId());
                                    if (provider != null) {
                                        companyName = provider.getCompanyName();
                                    }
                                } catch (Exception ex) {
                                    // Use default if error
                                }
                                
                                ((DefaultTableModel) jobsTable.getModel()).addRow(new Object[]{
                                    job.getId(),
                                    job.getTitle(),
                                    companyName,
                                    job.getType(),
                                    job.getLocation(),
                                    job.isActive() ? "Active" : "Inactive",
                                    job.getCreatedAt().format(dateFormatter),
                                    "Actions"
                                });
                            }
                        } else {
                            ((DefaultTableModel) jobsTable.getModel()).setRowCount(0);
                            for (Job job : jobs) {
                                // Get company name
                                String companyName = "Unknown";
                                try {
                                    JobProvider provider = userController.getJobProviderById(job.getProviderId());
                                    if (provider != null) {
                                        companyName = provider.getCompanyName();
                                    }
                                } catch (Exception ex) {
                                    // Use default if error
                                }
                                
                                // Check if job matches search
                                if (job.getTitle().toLowerCase().contains(searchText) ||
                                    companyName.toLowerCase().contains(searchText) ||
                                    job.getType().toLowerCase().contains(searchText) ||
                                    job.getLocation().toLowerCase().contains(searchText)) {
                                    
                                    ((DefaultTableModel) jobsTable.getModel()).addRow(new Object[]{
                                        job.getId(),
                                        job.getTitle(),
                                        companyName,
                                        job.getType(),
                                        job.getLocation(),
                                        job.isActive() ? "Active" : "Inactive",
                                        job.getCreatedAt().format(dateFormatter),
                                        "Actions"
                                    });
                                }
                            }
                        }
                    }
                });
            }
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading jobs: " + e.getMessage());
            errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
            jobsPanel.add(errorLabel, BorderLayout.CENTER);
        }
        
        // Add to content panel
        contentPanel.add(jobsPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Renderer for job management buttons in a table cell
     */
    private class JobButtonRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        private JButton viewButton;
        private JButton toggleButton;
        private JButton deleteButton;
        
        public JobButtonRenderer() {
            setLayout(new FlowLayout(FlowLayout.CENTER, 2, 0));
            viewButton = new JButton("View");
            viewButton.setPreferredSize(new Dimension(60, 25));
            toggleButton = new JButton("Toggle");
            toggleButton.setPreferredSize(new Dimension(70, 25));
            deleteButton = new JButton("Delete");
            deleteButton.setPreferredSize(new Dimension(70, 25));
            
            add(viewButton);
            add(toggleButton);
            add(deleteButton);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }
    
    /**
     * Editor for job management buttons in a table cell
     */
    private class JobButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton viewButton;
        private JButton toggleButton;
        private JButton deleteButton;
        private int selectedRow;
        private AdminDashboard dashboard;
        private List<Job> jobs;
        
        public JobButtonEditor(JTextField textField, AdminDashboard dashboard, List<Job> jobs) {
            super(textField);
            this.dashboard = dashboard;
            this.jobs = jobs;
            
            panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 0));
            
            viewButton = new JButton("View");
            viewButton.setPreferredSize(new Dimension(60, 25));
            toggleButton = new JButton("Toggle");
            toggleButton.setPreferredSize(new Dimension(70, 25));
            deleteButton = new JButton("Delete");
            deleteButton.setPreferredSize(new Dimension(70, 25));
            
            panel.add(viewButton);
            panel.add(toggleButton);
            panel.add(deleteButton);
            
            viewButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    viewJobDetails(jobs.get(selectedRow));
                }
            });
            
            toggleButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    toggleJobStatus(jobs.get(selectedRow));
                }
            });
            
            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    deleteJob(jobs.get(selectedRow));
                }
            });
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.selectedRow = table.convertRowIndexToModel(row);
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "Actions";
        }
    }
    
    /**
     * Shows detailed information about a job
     * 
     * @param job The job to display
     */
    private void viewJobDetails(Job job) {
        // Create dialog
        JDialog detailsDialog = new JDialog(this, "Job Details", true);
        detailsDialog.setSize(600, 500);
        detailsDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Job info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        
        try {
            // Get company info
            JobProvider provider = userController.getJobProviderById(job.getProviderId());
            
            // Job title
            JLabel titleLabel = new JLabel(job.getTitle());
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            // Company
            JLabel companyLabel = new JLabel(provider.getCompanyName());
            companyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            companyLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            // Status with colored background
            JPanel statusPanel = new JPanel();
            statusPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
            statusPanel.setBackground(job.isActive() ? new Color(40, 167, 69) : new Color(108, 117, 125));
            
            JLabel statusLabel = new JLabel(job.isActive() ? "Active" : "Inactive");
            statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
            statusLabel.setForeground(Color.WHITE);
            statusPanel.add(statusLabel);
            
            // Add components to info panel
            infoPanel.add(titleLabel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            infoPanel.add(companyLabel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            infoPanel.add(statusPanel);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
            
            // Job details section
            JPanel detailsGrid = new JPanel(new GridLayout(0, 2, 10, 5));
            detailsGrid.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            addField(detailsGrid, "Job Type:", job.getType());
            addField(detailsGrid, "Location:", job.getLocation());
            addField(detailsGrid, "Category:", job.getCategory());
            addField(detailsGrid, "Salary:", "$" + salaryFormatter.format(job.getSalary()));
            
            String deadline = job.getDeadlineDate() != null ? 
                             job.getDeadlineDate().format(dateFormatter) : 
                             "No deadline";
            addField(detailsGrid, "Deadline:", deadline);
            
            String created = job.getCreatedAt().format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm"));
            addField(detailsGrid, "Posted on:", created);
            
            infoPanel.add(detailsGrid);
            infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));
            
            // Tabbed pane for job details
            JTabbedPane tabbedPane = new JTabbedPane();
            tabbedPane.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            // Description tab
            JPanel descriptionPanel = new JPanel(new BorderLayout());
            JTextArea descriptionArea = new JTextArea(job.getDescription() != null ? job.getDescription() : "No description provided.");
            descriptionArea.setLineWrap(true);
            descriptionArea.setWrapStyleWord(true);
            descriptionArea.setEditable(false);
            JScrollPane descriptionScroll = new JScrollPane(descriptionArea);
            descriptionPanel.add(descriptionScroll, BorderLayout.CENTER);
            tabbedPane.addTab("Description", descriptionPanel);
            
            // Requirements tab
            JPanel requirementsPanel = new JPanel(new BorderLayout());
            JTextArea requirementsArea = new JTextArea(job.getRequirements() != null ? job.getRequirements() : "No requirements specified.");
            requirementsArea.setLineWrap(true);
            requirementsArea.setWrapStyleWord(true);
            requirementsArea.setEditable(false);
            JScrollPane requirementsScroll = new JScrollPane(requirementsArea);
            requirementsPanel.add(requirementsScroll, BorderLayout.CENTER);
            tabbedPane.addTab("Requirements", requirementsPanel);
            
            // Responsibilities tab
            JPanel responsibilitiesPanel = new JPanel(new BorderLayout());
            JTextArea responsibilitiesArea = new JTextArea(job.getResponsibilities() != null ? job.getResponsibilities() : "No responsibilities specified.");
            responsibilitiesArea.setLineWrap(true);
            responsibilitiesArea.setWrapStyleWord(true);
            responsibilitiesArea.setEditable(false);
            JScrollPane responsibilitiesScroll = new JScrollPane(responsibilitiesArea);
            responsibilitiesPanel.add(responsibilitiesScroll, BorderLayout.CENTER);
            tabbedPane.addTab("Responsibilities", responsibilitiesPanel);
            
            infoPanel.add(tabbedPane);
            
            // Add info panel to main panel
            JScrollPane mainScroll = new JScrollPane(infoPanel);
            mainScroll.setBorder(null);
            panel.add(mainScroll, BorderLayout.CENTER);
            
            // Button panel
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            
            // Toggle status button
            JButton toggleButton = new JButton(job.isActive() ? "Deactivate Job" : "Activate Job");
            toggleButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    toggleJobStatus(job);
                    detailsDialog.dispose();
                }
            });
            buttonPanel.add(toggleButton);
            
            // Close button
            JButton closeButton = new JButton("Close");
            closeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    detailsDialog.dispose();
                }
            });
            buttonPanel.add(closeButton);
            
            panel.add(buttonPanel, BorderLayout.SOUTH);
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading job details: " + e.getMessage());
            panel.add(errorLabel, BorderLayout.CENTER);
        }
        
        detailsDialog.add(panel);
        detailsDialog.setVisible(true);
    }
    
    /**
     * Toggles a job's active status
     * 
     * @param job The job to toggle status for
     */
    private void toggleJobStatus(Job job) {
        // Toggle status
        job.setActive(!job.isActive());
        
        // Update in database
        boolean success = jobController.updateJob(job);
        
        if (success) {
            JOptionPane.showMessageDialog(this,
                "Job status updated successfully.",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Refresh view
            showJobsManagement();
        } else {
            JOptionPane.showMessageDialog(this,
                "Failed to update job status.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Deletes a job from the system
     * 
     * @param job The job to delete
     */
    private void deleteJob(Job job) {
        // Confirm deletion
        int result = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this job? This action cannot be undone.",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            // Delete from database
            boolean success = jobController.deleteJob(job.getId(), job.getProviderId());
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Job deleted successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh view
                showJobsManagement();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to delete job.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * Opens the profile view
     */
    private void openProfileView() {
        // Refresh administrator data
        administrator = userController.getAdminById(administrator.getId());
        
        // Create profile view
        ProfileView profileView = new ProfileView(this, administrator);
        setContentPanel(profileView.getContentPanel());
    }
    
    /**
     * Sets the content of the content panel
     * 
     * @param newContent The new content panel
     */
    public void setContentPanel(JPanel newContent) {
        contentPanel.removeAll();
        contentPanel.add(newContent, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Refreshes the administrator data
     * 
     * @param updatedAdmin The updated administrator data
     */
    public void updateAdministrator(Administrator updatedAdmin) {
        this.administrator = updatedAdmin;
        welcomeLabel.setText("Welcome, Admin " + administrator.getFullName());
    }
    
    /**
     * Logs out the user
     */
    private void logout() {
        int result = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            dispose();
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
        }
    }
    
    /**
     * Gets the administrator
     * 
     * @return The administrator
     */
    public Administrator getAdministrator() {
        return administrator;
    }
}
