package com.jobportal.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Represents a job posting in the system.
 */
public class Job {
    private int id;
    private int providerId;
    private String title;
    private String description;
    private String requirements;
    private String responsibilities;
    private String location;
    private String type; // Full-time, Part-time, Contract, etc.
    private String category;
    private double salary;
    private LocalDate deadlineDate;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private boolean isActive;
    
    // Job type constants
    public static final String TYPE_FULL_TIME = "Full-time";
    public static final String TYPE_PART_TIME = "Part-time";
    public static final String TYPE_CONTRACT = "Contract";
    public static final String TYPE_INTERNSHIP = "Internship";
    public static final String TYPE_FREELANCE = "Freelance";
    
    /**
     * Default constructor
     */
    public Job() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.isActive = true;
    }
    
    /**
     * Constructor with essential job details
     * 
     * @param providerId ID of the job provider
     * @param title Job title
     * @param description Job description
     * @param requirements Job requirements
     * @param location Job location
     * @param type Job type
     * @param category Job category
     * @param salary Job salary
     * @param deadlineDate Application deadline date
     */
    public Job(int providerId, String title, String description, String requirements, 
              String responsibilities, String location, String type, String category, 
              double salary, LocalDate deadlineDate) {
        this();
        this.providerId = providerId;
        this.title = title;
        this.description = description;
        this.requirements = requirements;
        this.responsibilities = responsibilities;
        this.location = location;
        this.type = type;
        this.category = category;
        this.salary = salary;
        this.deadlineDate = deadlineDate;
    }
    
    /**
     * Complete constructor with all fields
     * 
     * @param id Job ID
     * @param providerId ID of the job provider
     * @param title Job title
     * @param description Job description
     * @param requirements Job requirements
     * @param responsibilities Job responsibilities
     * @param location Job location
     * @param type Job type
     * @param category Job category
     * @param salary Job salary
     * @param deadlineDate Application deadline date
     * @param createdAt Job creation timestamp
     * @param updatedAt Job update timestamp
     * @param isActive Job active status
     */
    public Job(int id, int providerId, String title, String description, String requirements, 
              String responsibilities, String location, String type, String category, 
              double salary, LocalDate deadlineDate, LocalDateTime createdAt, 
              LocalDateTime updatedAt, boolean isActive) {
        this.id = id;
        this.providerId = providerId;
        this.title = title;
        this.description = description;
        this.requirements = requirements;
        this.responsibilities = responsibilities;
        this.location = location;
        this.type = type;
        this.category = category;
        this.salary = salary;
        this.deadlineDate = deadlineDate;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.isActive = isActive;
    }
    
    // Getters and setters
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getProviderId() {
        return providerId;
    }
    
    public void setProviderId(int providerId) {
        this.providerId = providerId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getRequirements() {
        return requirements;
    }
    
    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }
    
    public String getResponsibilities() {
        return responsibilities;
    }
    
    public void setResponsibilities(String responsibilities) {
        this.responsibilities = responsibilities;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    public LocalDate getDeadlineDate() {
        return deadlineDate;
    }
    
    public void setDeadlineDate(LocalDate deadlineDate) {
        this.deadlineDate = deadlineDate;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    /**
     * Update the last modified timestamp
     */
    public void updateTimestamp() {
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * Check if the job application deadline has passed
     * 
     * @return true if the deadline has passed, false otherwise
     */
    public boolean isDeadlinePassed() {
        return deadlineDate != null && deadlineDate.isBefore(LocalDate.now());
    }
    
    @Override
    public String toString() {
        return "Job{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", location='" + location + '\'' +
                ", salary=" + salary +
                ", deadlineDate=" + deadlineDate +
                '}';
    }
}
