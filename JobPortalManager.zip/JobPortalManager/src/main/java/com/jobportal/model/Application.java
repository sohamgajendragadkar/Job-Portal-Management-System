package com.jobportal.model;

import java.time.LocalDateTime;

/**
 * Represents a job application in the system.
 */
public class Application {
    private int id;
    private int jobId;
    private int seekerId;
    private String coverLetter;
    private String status;
    private LocalDateTime appliedAt;
    private LocalDateTime updatedAt;
    private String notes;
    
    // Application status constants
    public static final String STATUS_PENDING = "Pending";
    public static final String STATUS_REVIEWING = "Reviewing";
    public static final String STATUS_SHORTLISTED = "Shortlisted";
    public static final String STATUS_INTERVIEW = "Interview";
    public static final String STATUS_OFFERED = "Offered";
    public static final String STATUS_HIRED = "Hired";
    public static final String STATUS_REJECTED = "Rejected";
    public static final String STATUS_WITHDRAWN = "Withdrawn";
    
    /**
     * Default constructor
     */
    public Application() {
        this.appliedAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.status = STATUS_PENDING;
    }
    
    /**
     * Constructor with essential application details
     * 
     * @param jobId ID of the job being applied for
     * @param seekerId ID of the job seeker applying
     * @param coverLetter Cover letter for the application
     */
    public Application(int jobId, int seekerId, String coverLetter) {
        this();
        this.jobId = jobId;
        this.seekerId = seekerId;
        this.coverLetter = coverLetter;
    }
    
    /**
     * Complete constructor with all fields
     * 
     * @param id Application ID
     * @param jobId ID of the job being applied for
     * @param seekerId ID of the job seeker applying
     * @param coverLetter Cover letter for the application
     * @param status Status of the application
     * @param appliedAt Application creation timestamp
     * @param updatedAt Application update timestamp
     * @param notes Additional notes about the application
     */
    public Application(int id, int jobId, int seekerId, String coverLetter, String status,
                      LocalDateTime appliedAt, LocalDateTime updatedAt, String notes) {
        this.id = id;
        this.jobId = jobId;
        this.seekerId = seekerId;
        this.coverLetter = coverLetter;
        this.status = status;
        this.appliedAt = appliedAt;
        this.updatedAt = updatedAt;
        this.notes = notes;
    }
    
    // Getters and setters
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getJobId() {
        return jobId;
    }
    
    public void setJobId(int jobId) {
        this.jobId = jobId;
    }
    
    public int getSeekerId() {
        return seekerId;
    }
    
    public void setSeekerId(int seekerId) {
        this.seekerId = seekerId;
    }
    
    public String getCoverLetter() {
        return coverLetter;
    }
    
    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
        this.updatedAt = LocalDateTime.now();
    }
    
    public LocalDateTime getAppliedAt() {
        return appliedAt;
    }
    
    public void setAppliedAt(LocalDateTime appliedAt) {
        this.appliedAt = appliedAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public String getNotes() {
        return notes;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * Updates the application status and timestamp
     * 
     * @param newStatus The new status to set
     */
    public void updateStatus(String newStatus) {
        this.status = newStatus;
        this.updatedAt = LocalDateTime.now();
    }
    
    @Override
    public String toString() {
        return "Application{" +
                "id=" + id +
                ", jobId=" + jobId +
                ", seekerId=" + seekerId +
                ", status='" + status + '\'' +
                ", appliedAt=" + appliedAt +
                '}';
    }
}
