package com.jobportal.model;

import java.time.LocalDateTime;

/**
 * Base class representing a user in the system.
 * This is an abstract class that serves as a parent for specific user types.
 */
public abstract class User {
    private int id;
    private String username;
    private String password; // In production, this would be stored as a hashed value
    private String email;
    private String fullName;
    private String phone;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;
    private boolean isActive;
    
    // User types
    public static final int JOB_SEEKER = 1;
    public static final int JOB_PROVIDER = 2;
    public static final int ADMINISTRATOR = 3;
    
    /**
     * Default constructor
     */
    public User() {
        this.createdAt = LocalDateTime.now();
        this.isActive = true;
    }
    
    /**
     * Constructor with parameters
     * 
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     */
    public User(String username, String password, String email, String fullName, String phone) {
        this();
        this.username = username;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.phone = phone;
    }
    
    /**
     * Constructor with ID and parameters
     * 
     * @param id User's ID
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     * @param createdAt User creation timestamp
     * @param lastLogin User's last login timestamp
     * @param isActive User's active status
     */
    public User(int id, String username, String password, String email, String fullName, 
                String phone, LocalDateTime createdAt, LocalDateTime lastLogin, boolean isActive) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.phone = phone;
        this.createdAt = createdAt;
        this.lastLogin = lastLogin;
        this.isActive = isActive;
    }
    
    /**
     * Get the type of user
     * 
     * @return An integer representing the user type
     */
    public abstract int getUserType();
    
    // Getters and setters
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getLastLogin() {
        return lastLogin;
    }
    
    public void setLastLogin(LocalDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    public void updateLastLogin() {
        this.lastLogin = LocalDateTime.now();
    }
    
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", fullName='" + fullName + '\'' +
                '}';
    }
}
