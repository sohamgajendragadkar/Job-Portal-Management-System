package com.jobportal.model;

import java.time.LocalDateTime;

/**
 * Represents an administrator user in the system.
 * Extends the base User class with additional fields specific to administrators.
 */
public class Administrator extends User {
    private String role;
    private String department;
    private int accessLevel;
    
    /**
     * Default constructor
     */
    public Administrator() {
        super();
    }
    
    /**
     * Constructor with basic user information
     * 
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     */
    public Administrator(String username, String password, String email, String fullName, String phone) {
        super(username, password, email, fullName, phone);
    }
    
    /**
     * Complete constructor with all fields
     * 
     * @param id User's ID
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     * @param createdAt User creation timestamp
     * @param lastLogin User's last login timestamp
     * @param isActive User's active status
     * @param role Administrator's role
     * @param department Administrator's department
     * @param accessLevel Administrator's access level
     */
    public Administrator(int id, String username, String password, String email, String fullName, 
                     String phone, LocalDateTime createdAt, LocalDateTime lastLogin, boolean isActive,
                     String role, String department, int accessLevel) {
        super(id, username, password, email, fullName, phone, createdAt, lastLogin, isActive);
        this.role = role;
        this.department = department;
        this.accessLevel = accessLevel;
    }
    
    @Override
    public int getUserType() {
        return User.ADMINISTRATOR;
    }
    
    // Getters and setters
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    public int getAccessLevel() {
        return accessLevel;
    }
    
    public void setAccessLevel(int accessLevel) {
        this.accessLevel = accessLevel;
    }
    
    @Override
    public String toString() {
        return "Administrator{" +
                "id=" + getId() +
                ", username='" + getUsername() + '\'' +
                ", role='" + role + '\'' +
                ", accessLevel=" + accessLevel +
                '}';
    }
}
