package com.jobportal.model;

import java.time.LocalDateTime;

/**
 * Represents a job seeker user in the system.
 * Extends the base User class with additional fields specific to job seekers.
 */
public class JobSeeker extends User {
    private String resume;
    private String skills;
    private String education;
    private String experience;
    private String preferences;
    
    /**
     * Default constructor
     */
    public JobSeeker() {
        super();
    }
    
    /**
     * Constructor with basic user information
     * 
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     */
    public JobSeeker(String username, String password, String email, String fullName, String phone) {
        super(username, password, email, fullName, phone);
    }
    
    /**
     * Complete constructor with all fields
     * 
     * @param id User's ID
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     * @param createdAt User creation timestamp
     * @param lastLogin User's last login timestamp
     * @param isActive User's active status
     * @param resume Job seeker's resume
     * @param skills Job seeker's skills
     * @param education Job seeker's education
     * @param experience Job seeker's experience
     * @param preferences Job seeker's job preferences
     */
    public JobSeeker(int id, String username, String password, String email, String fullName, 
                    String phone, LocalDateTime createdAt, LocalDateTime lastLogin, boolean isActive,
                    String resume, String skills, String education, String experience, String preferences) {
        super(id, username, password, email, fullName, phone, createdAt, lastLogin, isActive);
        this.resume = resume;
        this.skills = skills;
        this.education = education;
        this.experience = experience;
        this.preferences = preferences;
    }
    
    @Override
    public int getUserType() {
        return User.JOB_SEEKER;
    }
    
    // Getters and setters
    
    public String getResume() {
        return resume;
    }
    
    public void setResume(String resume) {
        this.resume = resume;
    }
    
    public String getSkills() {
        return skills;
    }
    
    public void setSkills(String skills) {
        this.skills = skills;
    }
    
    public String getEducation() {
        return education;
    }
    
    public void setEducation(String education) {
        this.education = education;
    }
    
    public String getExperience() {
        return experience;
    }
    
    public void setExperience(String experience) {
        this.experience = experience;
    }
    
    public String getPreferences() {
        return preferences;
    }
    
    public void setPreferences(String preferences) {
        this.preferences = preferences;
    }
    
    @Override
    public String toString() {
        return "JobSeeker{" +
                "id=" + getId() +
                ", username='" + getUsername() + '\'' +
                ", fullName='" + getFullName() + '\'' +
                ", skills='" + skills + '\'' +
                '}';
    }
}
