package com.jobportal.model;

import java.time.LocalDateTime;

/**
 * Represents a job provider (employer) user in the system.
 * Extends the base User class with additional fields specific to job providers.
 */
public class JobProvider extends User {
    private String companyName;
    private String companyDescription;
    private String industry;
    private String website;
    private String location;
    
    /**
     * Default constructor
     */
    public JobProvider() {
        super();
    }
    
    /**
     * Constructor with basic user information
     * 
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     */
    public JobProvider(String username, String password, String email, String fullName, String phone) {
        super(username, password, email, fullName, phone);
    }
    
    /**
     * Complete constructor with all fields
     * 
     * @param id User's ID
     * @param username User's username
     * @param password User's password
     * @param email User's email
     * @param fullName User's full name
     * @param phone User's phone number
     * @param createdAt User creation timestamp
     * @param lastLogin User's last login timestamp
     * @param isActive User's active status
     * @param companyName Company name
     * @param companyDescription Company description
     * @param industry Company industry
     * @param website Company website
     * @param location Company location
     */
    public JobProvider(int id, String username, String password, String email, String fullName, 
                      String phone, LocalDateTime createdAt, LocalDateTime lastLogin, boolean isActive,
                      String companyName, String companyDescription, String industry, String website, String location) {
        super(id, username, password, email, fullName, phone, createdAt, lastLogin, isActive);
        this.companyName = companyName;
        this.companyDescription = companyDescription;
        this.industry = industry;
        this.website = website;
        this.location = location;
    }
    
    @Override
    public int getUserType() {
        return User.JOB_PROVIDER;
    }
    
    // Getters and setters
    
    public String getCompanyName() {
        return companyName;
    }
    
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
    public String getCompanyDescription() {
        return companyDescription;
    }
    
    public void setCompanyDescription(String companyDescription) {
        this.companyDescription = companyDescription;
    }
    
    public String getIndustry() {
        return industry;
    }
    
    public void setIndustry(String industry) {
        this.industry = industry;
    }
    
    public String getWebsite() {
        return website;
    }
    
    public void setWebsite(String website) {
        this.website = website;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    @Override
    public String toString() {
        return "JobProvider{" +
                "id=" + getId() +
                ", username='" + getUsername() + '\'' +
                ", companyName='" + companyName + '\'' +
                ", industry='" + industry + '\'' +
                '}';
    }
}
