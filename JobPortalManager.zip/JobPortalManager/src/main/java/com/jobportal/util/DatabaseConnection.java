package com.jobportal.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton class to manage database connections throughout the application.
 * Provides connection to MySQL database.
 */
public class DatabaseConnection {
    private static DatabaseConnection instance;
    private Connection connection;
    
    // Database configuration
    private final String url = "jdbc:mysql://localhost:3306/jobportal";
    private final String username = "root";
    private final String password = ""; // In real application, this should be secured
    
    /**
     * Private constructor to prevent instantiation outside of this class.
     * Loads the JDBC driver and establishes a connection.
     * 
     * @throws SQLException If a database error occurs
     * @throws ClassNotFoundException If the MySQL JDBC driver is not found
     */
    private DatabaseConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        this.connection = DriverManager.getConnection(url, username, password);
    }
    
    /**
     * Gets the singleton instance of DatabaseConnection, creating it if needed.
     * 
     * @return The DatabaseConnection instance
     * @throws SQLException If a database error occurs
     * @throws ClassNotFoundException If the MySQL JDBC driver is not found
     */
    public static synchronized DatabaseConnection getInstance() throws SQLException, ClassNotFoundException {
        if (instance == null || instance.getConnection().isClosed()) {
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    /**
     * Gets the active database connection.
     * 
     * @return The Connection object
     */
    public Connection getConnection() {
        return connection;
    }
    
    /**
     * Closes the database connection.
     * 
     * @throws SQLException If an error occurs while closing the connection
     */
    public void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
