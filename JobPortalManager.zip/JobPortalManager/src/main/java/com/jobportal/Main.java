package com.jobportal;

import com.jobportal.view.LoginView;
import com.jobportal.util.DatabaseConnection;

import javax.swing.*;
import java.awt.*;

/**
 * Main entry point for the Job Portal Management System.
 * This application allows job seekers to find jobs, job providers
 * to post jobs, and administrators to oversee the system.
 */
public class Main {
    public static void main(String[] args) {
        // Set look and feel to the system look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Initialize database connection
        try {
            DatabaseConnection.getInstance();
            System.out.println("Database connection established successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, 
                "Failed to connect to database: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        // Start the application with the login screen
        SwingUtilities.invokeLater(() -> {
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
        });
    }
}
