package com.jobportal.controller;

import com.jobportal.model.Administrator;
import com.jobportal.model.JobProvider;
import com.jobportal.model.JobSeeker;
import com.jobportal.model.User;
import com.jobportal.dao.UserDAO;

import java.sql.SQLException;

/**
 * Controller class for authentication operations.
 * Handles user login, registration, and related functionality.
 */
public class AuthController {
    private UserDAO userDAO;
    
    /**
     * Constructor to initialize the controller with necessary DAO
     */
    public AuthController() {
        this.userDAO = new UserDAO();
    }
    
    /**
     * Authenticates a user based on username and password
     * 
     * @param username The username to check
     * @param password The password to verify
     * @return A User object if authentication is successful, null otherwise
     */
    public User login(String username, String password) {
        try {
            return userDAO.authenticateUser(username, password);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Registers a new job seeker
     * 
     * @param jobSeeker The JobSeeker object to register
     * @return The registered JobSeeker with ID if successful, null otherwise
     */
    public JobSeeker registerJobSeeker(JobSeeker jobSeeker) {
        try {
            // Validate username and email uniqueness
            if (userDAO.isUsernameTaken(jobSeeker.getUsername())) {
                throw new IllegalArgumentException("Username is already taken");
            }
            
            if (userDAO.isEmailTaken(jobSeeker.getEmail())) {
                throw new IllegalArgumentException("Email is already registered");
            }
            
            // Create the job seeker
            return userDAO.createJobSeeker(jobSeeker);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Registers a new job provider
     * 
     * @param jobProvider The JobProvider object to register
     * @return The registered JobProvider with ID if successful, null otherwise
     */
    public JobProvider registerJobProvider(JobProvider jobProvider) {
        try {
            // Validate username and email uniqueness
            if (userDAO.isUsernameTaken(jobProvider.getUsername())) {
                throw new IllegalArgumentException("Username is already taken");
            }
            
            if (userDAO.isEmailTaken(jobProvider.getEmail())) {
                throw new IllegalArgumentException("Email is already registered");
            }
            
            // Create the job provider
            return userDAO.createJobProvider(jobProvider);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Registers a new administrator (usually only for system initialization)
     * 
     * @param admin The Administrator object to register
     * @return The registered Administrator with ID if successful, null otherwise
     */
    public Administrator registerAdmin(Administrator admin) {
        try {
            // Validate username and email uniqueness
            if (userDAO.isUsernameTaken(admin.getUsername())) {
                throw new IllegalArgumentException("Username is already taken");
            }
            
            if (userDAO.isEmailTaken(admin.getEmail())) {
                throw new IllegalArgumentException("Email is already registered");
            }
            
            // Create the administrator
            return userDAO.createAdmin(admin);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Validates username availability
     * 
     * @param username The username to check
     * @return true if the username is available, false if already taken
     */
    public boolean isUsernameAvailable(String username) {
        try {
            return !userDAO.isUsernameTaken(username);
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Assume username is taken if error occurs
        }
    }
    
    /**
     * Validates email availability
     * 
     * @param email The email to check
     * @return true if the email is available, false if already registered
     */
    public boolean isEmailAvailable(String email) {
        try {
            return !userDAO.isEmailTaken(email);
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Assume email is taken if error occurs
        }
    }
}
