package com.jobportal.controller;

import com.jobportal.model.Application;
import com.jobportal.dao.ApplicationDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller class for application-related operations.
 * Handles job application submission, status management, and retrieval.
 */
public class ApplicationController {
    private ApplicationDAO applicationDAO;
    
    /**
     * Constructor to initialize the controller with necessary DAO
     */
    public ApplicationController() {
        this.applicationDAO = new ApplicationDAO();
    }
    
    /**
     * Creates a new job application
     * 
     * @param application The Application object to create
     * @return The created Application with ID if successful, null otherwise
     */
    public Application applyForJob(Application application) {
        try {
            // Check if the seeker has already applied for this job
            if (applicationDAO.hasApplied(application.getJobId(), application.getSeekerId())) {
                throw new IllegalStateException("You have already applied for this job");
            }
            
            return applicationDAO.createApplication(application);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Gets an application by its ID
     * 
     * @param applicationId The ID of the application to retrieve
     * @return The Application object if found, null otherwise
     */
    public Application getApplicationById(int applicationId) {
        try {
            return applicationDAO.getApplicationById(applicationId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Updates an application status
     * 
     * @param application The Application object with updated status
     * @return true if update was successful, false otherwise
     */
    public boolean updateApplicationStatus(Application application) {
        try {
            return applicationDAO.updateApplication(application);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Gets all applications for a specific job
     * 
     * @param jobId The ID of the job
     * @return List of applications for the job
     */
    public List<Application> getApplicationsByJob(int jobId) {
        try {
            return applicationDAO.getApplicationsByJob(jobId);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Gets all applications submitted by a specific job seeker
     * 
     * @param seekerId The ID of the job seeker
     * @return List of applications submitted by the job seeker
     */
    public List<Application> getApplicationsBySeeker(int seekerId) {
        try {
            return applicationDAO.getApplicationsBySeeker(seekerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Gets job seeker applications with corresponding job details
     * 
     * @param seekerId The ID of the job seeker
     * @return List containing arrays of [Application, Job, CompanyName]
     */
    public List<Object[]> getApplicationsWithJobDetails(int seekerId) {
        try {
            return applicationDAO.getApplicationsWithJobDetails(seekerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Withdraws an application from consideration
     * 
     * @param applicationId The ID of the application to withdraw
     * @param seekerId The ID of the job seeker (for verification)
     * @return true if withdrawal was successful, false otherwise
     */
    public boolean withdrawApplication(int applicationId, int seekerId) {
        try {
            return applicationDAO.withdrawApplication(applicationId, seekerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Gets application statistics for a job provider
     * 
     * @param providerId The ID of the job provider
     * @return int array with statistics values [total, pending, reviewing, shortlisted, hired]
     */
    public int[] getApplicationStatistics(int providerId) {
        try {
            return applicationDAO.getApplicationStatistics(providerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return new int[5]; // Return empty stats if error occurs
        }
    }
    
    /**
     * Checks if a job seeker has already applied to a job
     * 
     * @param jobId The job ID
     * @param seekerId The job seeker ID
     * @return true if the seeker has already applied, false otherwise
     */
    public boolean hasAppliedToJob(int jobId, int seekerId) {
        try {
            return applicationDAO.hasApplied(jobId, seekerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
