package com.jobportal.controller;

import com.jobportal.model.Administrator;
import com.jobportal.model.JobProvider;
import com.jobportal.model.JobSeeker;
import com.jobportal.model.User;
import com.jobportal.dao.UserDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller class for user-related operations.
 * Handles user profile management and retrieval.
 */
public class UserController {
    private UserDAO userDAO;
    
    /**
     * Constructor to initialize the controller with necessary DAO
     */
    public UserController() {
        this.userDAO = new UserDAO();
    }
    
    /**
     * Gets a job seeker by ID
     * 
     * @param seekerId The ID of the job seeker to retrieve
     * @return The JobSeeker object if found, null otherwise
     */
    public JobSeeker getJobSeekerById(int seekerId) {
        try {
            return userDAO.getJobSeekerById(seekerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Gets a job provider by ID
     * 
     * @param providerId The ID of the job provider to retrieve
     * @return The JobProvider object if found, null otherwise
     */
    public JobProvider getJobProviderById(int providerId) {
        try {
            return userDAO.getJobProviderById(providerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Gets an administrator by ID
     * 
     * @param adminId The ID of the administrator to retrieve
     * @return The Administrator object if found, null otherwise
     */
    public Administrator getAdminById(int adminId) {
        try {
            return userDAO.getAdminById(adminId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Updates a job seeker's profile
     * 
     * @param jobSeeker The JobSeeker object with updated information
     * @return true if update was successful, false otherwise
     */
    public boolean updateJobSeekerProfile(JobSeeker jobSeeker) {
        try {
            return userDAO.updateJobSeeker(jobSeeker);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Updates a job provider's profile
     * 
     * @param jobProvider The JobProvider object with updated information
     * @return true if update was successful, false otherwise
     */
    public boolean updateJobProviderProfile(JobProvider jobProvider) {
        try {
            return userDAO.updateJobProvider(jobProvider);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Updates an administrator's profile
     * 
     * @param admin The Administrator object with updated information
     * @return true if update was successful, false otherwise
     */
    public boolean updateAdminProfile(Administrator admin) {
        try {
            return userDAO.updateAdmin(admin);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Deletes a user from the system
     * 
     * @param userId The ID of the user to delete
     * @param userType The type of the user
     * @return true if deletion was successful, false otherwise
     */
    public boolean deleteUser(int userId, int userType) {
        try {
            return userDAO.deleteUser(userId, userType);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Gets all job seekers (admin functionality)
     * 
     * @return List of all job seekers
     */
    public List<JobSeeker> getAllJobSeekers() {
        try {
            return userDAO.getAllJobSeekers();
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Gets all job providers (admin functionality)
     * 
     * @return List of all job providers
     */
    public List<JobProvider> getAllJobProviders() {
        try {
            return userDAO.getAllJobProviders();
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}
