package com.jobportal.controller;

import com.jobportal.model.Job;
import com.jobportal.dao.JobDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller class for job-related operations.
 * Handles job posting, searching, updating, and deletion.
 */
public class JobController {
    private JobDAO jobDAO;
    
    /**
     * Constructor to initialize the controller with necessary DAO
     */
    public JobController() {
        this.jobDAO = new JobDAO();
    }
    
    /**
     * Creates a new job posting
     * 
     * @param job The Job object to create
     * @return The created Job with ID if successful, null otherwise
     */
    public Job createJob(Job job) {
        try {
            return jobDAO.createJob(job);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Gets a job by its ID
     * 
     * @param jobId The ID of the job to retrieve
     * @return The Job object if found, null otherwise
     */
    public Job getJobById(int jobId) {
        try {
            return jobDAO.getJobById(jobId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Updates an existing job
     * 
     * @param job The Job object to update
     * @return true if update was successful, false otherwise
     */
    public boolean updateJob(Job job) {
        try {
            return jobDAO.updateJob(job);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Deletes a job posting
     * 
     * @param jobId The ID of the job to delete
     * @param providerId The ID of the provider who owns the job
     * @return true if deletion was successful, false otherwise
     */
    public boolean deleteJob(int jobId, int providerId) {
        try {
            return jobDAO.deleteJob(jobId, providerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Gets all jobs posted by a specific provider
     * 
     * @param providerId The ID of the provider
     * @return List of jobs posted by the provider
     */
    public List<Job> getJobsByProvider(int providerId) {
        try {
            return jobDAO.getJobsByProvider(providerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Searches for jobs based on various criteria
     * 
     * @param title Optional job title to search for
     * @param location Optional job location to search for
     * @param type Optional job type to filter by
     * @param category Optional job category to filter by
     * @param minSalary Optional minimum salary to filter by
     * @return List of jobs matching the search criteria
     */
    public List<Job> searchJobs(String title, String location, String type, String category, Double minSalary) {
        try {
            return jobDAO.searchJobs(title, location, type, category, minSalary);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Gets recently posted active jobs
     * 
     * @param limit The maximum number of jobs to return
     * @return List of recent jobs
     */
    public List<Job> getRecentJobs(int limit) {
        try {
            return jobDAO.getRecentJobs(limit);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Gets all job categories from the database
     * 
     * @return List of unique job categories
     */
    public List<String> getAllJobCategories() {
        try {
            return jobDAO.getAllJobCategories();
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * Gets all job locations from the database
     * 
     * @return List of unique job locations
     */
    public List<String> getAllJobLocations() {
        try {
            return jobDAO.getAllJobLocations();
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}
